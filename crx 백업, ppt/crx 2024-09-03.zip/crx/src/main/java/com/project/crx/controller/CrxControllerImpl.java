package com.project.crx.controller;

import java.sql.Time;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.project.crx.service.CrxService;
import com.project.crx.vo.CrxScheduleVO;
import com.project.crx.vo.CrxVO;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@Controller
public class CrxControllerImpl implements CrxController {

	@Autowired
	private CrxService crxService;

	@Autowired
	private CrxVO crxVO;
	
	@Autowired
	private CrxScheduleVO crxScheduleVO;

	@GetMapping("/main.do")
	public ModelAndView mainNotice(HttpServletRequest request, HttpServletResponse response) throws Exception {
		List<CrxVO> mainNotice = crxService.mainNotice();
		ModelAndView mav = new ModelAndView("main");
		mav.addObject("mainNotice", mainNotice);
		return mav;
	}

	@GetMapping("/login.do")
	public String login() {
		return "login"; // login.jsp와 같은 뷰 이름을 반환
	}

	@Override
	@PostMapping("/login.do")
	public ModelAndView login(CrxVO crxVO, RedirectAttributes rAttr, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();

		CrxVO loginUser = null;
		String loginType = request.getParameter("loginType");

		if (loginType == null || "user".equals(loginType)) {
			loginUser = crxService.login(crxVO);
		} else if ("member".equals(loginType)) {
			loginUser = crxService.login(crxVO);
		}

		if (loginUser != null) {
			// 로그인 성공
			HttpSession session = request.getSession();
			session.setAttribute("loginUser", loginUser);
			session.setAttribute("username", loginUser.getUsername());
			session.setAttribute("userid", loginUser.getUserid());
			session.setAttribute("level", loginUser.getLevel());
			session.setAttribute("divname", loginUser.getDivname());
			session.setAttribute("status", loginUser.getStatus());
			session.setAttribute("isLogOn", true);
			session.setMaxInactiveInterval(1800); // 30분 세션 유지

			mav.setViewName("redirect:/main.do");
		} else {
			rAttr.addFlashAttribute("result", "회원번호 또는 비밀번호가 일치하지 않습니다.");
			mav.setViewName("redirect:/login.do");
		}

		return mav;
	}

	@Override
	@GetMapping("/logout.do")
	public ModelAndView logout(HttpServletRequest request, HttpServletResponse response) throws Exception {
		HttpSession session = request.getSession();
		session.invalidate(); // 세션 무효화

		// 모든 쿠키 삭제
		Cookie[] cookies = request.getCookies();
		if (cookies != null) {
			for (Cookie cookie : cookies) {
				cookie.setValue(null);
				cookie.setMaxAge(0);
				cookie.setPath("/"); // 쿠키 경로 설정
				response.addCookie(cookie);
			}
		}

		return new ModelAndView("redirect:/main.do"); // 로그인 페이지로 리다이렉트
	}

	@PostMapping("/updateUserInfo.do")
	public ModelAndView updateUserInfo(@ModelAttribute("crx") CrxVO crxVO, RedirectAttributes rAttr,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		HttpSession session = request.getSession();
		Integer userIdInt = (Integer) session.getAttribute("userid");

		if (userIdInt == null) {
			return new ModelAndView("redirect:/login.do"); // 로그인 페이지로 리다이렉트
		}

		// 사용자 정보 가져오기
		CrxVO currentUser = crxService.userInfo(userIdInt);

		// level에 따라 수정할 테이블 결정
		if ("user".equals(currentUser.getLevel())) {
			// user 테이블 업데이트 전에 주소 필드가 비어 있는지 확인
			if (crxVO.getUseradd() == null || crxVO.getUseradd().trim().isEmpty()) {
				crxVO.setUseradd(currentUser.getUseradd());
			}
			if (crxVO.getUserpost() == null || crxVO.getUserpost().trim().isEmpty()) {
				crxVO.setUserpost(currentUser.getUserpost());
			}

			// user 테이블에서 업데이트
			crxVO.setUserid(userIdInt); // userId 설정
			crxService.updateUserInfo(crxVO);
		} else {
			// member 테이블 업데이트 전에 주소 필드가 비어 있는지 확인
			if (crxVO.getMemadd() == null || crxVO.getMemadd().trim().isEmpty()) {
				crxVO.setMemadd(currentUser.getMemadd());
			}
			if (crxVO.getMempost() == null || crxVO.getMempost().trim().isEmpty()) {
				crxVO.setMempost(currentUser.getMempost());
			}

			// member 테이블에서 업데이트
			crxVO.setMemid(userIdInt); // memberId 설정
			crxService.updateMemberInfo(crxVO);
		}

		// 세션 갱신
		session.setAttribute("crxVO", crxVO);

		rAttr.addFlashAttribute("updateSuccess", true);
		return new ModelAndView("redirect:/mypage.do");
	}

	@Override
	@GetMapping("/confirm.do")
	public ModelAndView confirm(HttpServletRequest request, HttpServletResponse response) throws Exception {
		return new ModelAndView("confirm");
	}

	@Override
	@GetMapping("/childConfirm.do")
	public ModelAndView childConfirm(HttpServletRequest request, HttpServletResponse response) throws Exception {
		return new ModelAndView("childConfirm");
	}

	@Override
	@GetMapping("/findId.do")
	public ModelAndView findId(HttpServletRequest request, HttpServletResponse response) throws Exception {
		return new ModelAndView("findId");
	}

	@Override
	@PostMapping("/findIdConfirm.do")
	public ModelAndView findIdConfirm(@ModelAttribute("crx") CrxVO crxVO, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();

		// 입력된 username과 usertel로 사용자를 찾음
		CrxVO user = crxService.findUserId(crxVO);

		if (user != null) {
			// 일치하는 사용자가 있을 경우
			HttpSession session = request.getSession();
			session.setAttribute("foundUserid", user.getUserid()); // userid를 세션에 저장

			mav.setViewName("findIdConfirm"); // SMS 인증 페이지로 이동
		} else {
			// 일치하지 않을 경우
			mav.addObject("result", "입력하신 정보와 일치하는 회원이 없습니다.");
			mav.setViewName("findId");
		}
		return mav;
	}

	@Override
	@GetMapping("/findPwd.do")
	public ModelAndView findPwd(HttpServletRequest request, HttpServletResponse response) throws Exception {
		return new ModelAndView("findPwd");
	}

	@Override
	@PostMapping("/findPwdConfirm.do")
	public ModelAndView findPwdConfirm(@ModelAttribute("crx") CrxVO crxVO, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();

		// 입력된 username과 userid로 사용자를 찾음
		CrxVO user = crxService.findUserPwd(crxVO);

		if (user != null) {
			// 일치하는 사용자가 있을 경우
			HttpSession session = request.getSession();
			session.setAttribute("foundUsername", user.getUsername()); // username을 세션에 저장
			session.setAttribute("foundUserpwd", user.getUserpwd()); // userpwd를 세션에 저장

			mav.setViewName("findPwdConfirm"); // SMS 인증 페이지로 이동
		} else {
			// 일치하지 않을 경우
			mav.addObject("result", "입력하신 정보와 일치하는 회원이 없습니다.");
			mav.setViewName("findPwd");
		}
		return mav;
	}

	@Override
	@GetMapping("/signup.do")
	public ModelAndView signup(HttpServletRequest request, HttpServletResponse response) throws Exception {
		return new ModelAndView("signup");
	}

	@Override
	@GetMapping("/childSignup.do")
	public ModelAndView childSignup(HttpServletRequest request, HttpServletResponse response) throws Exception {
		return new ModelAndView("childSignup");
	}

	@Override
	@PostMapping("/finishSignup.do")
	public ModelAndView finishSignup(@ModelAttribute("crx") CrxVO crxVO, HttpServletRequest request,
			HttpServletResponse response, RedirectAttributes rAttr) throws Exception {
		ModelAndView mav = new ModelAndView();

		// 14세 미만 회원 중복 확인
		boolean isChildExist = crxService.existChildUser(crxVO.getUsername(), crxVO.getParenttel());

		if (isChildExist) {
			rAttr.addFlashAttribute("errorMessage", "이미 존재하는 회원입니다.");
			mav.setViewName("redirect:/childSignup.do");
			return mav;
		}

		// 14세 이상 회원 중복 확인
		boolean isUserExist = crxService.existUser(crxVO.getUsername(), crxVO.getUsertel());

		if (isUserExist) {
			rAttr.addFlashAttribute("errorMessage", "이미 존재하는 회원입니다.");
			mav.setViewName("redirect:/signup.do");
			return mav;
		}

		// 회원가입 처리 로직 (DB에 사용자 정보 저장)
		crxService.registerUser(crxVO);

		int userId = crxVO.getUserid();

		mav.addObject("userid", userId);
		mav.addObject("username", crxVO.getUsername());
		mav.setViewName("finishSignup");

		return mav;
	}

	@Override
	@GetMapping("/signupTerms.do")
	public ModelAndView signupTerms(HttpServletRequest request, HttpServletResponse response) throws Exception {
		return new ModelAndView("signupTerms");
	}

	@Override
	@GetMapping("/finishFindId.do")
	public ModelAndView finishFindId(HttpServletRequest request, HttpServletResponse response) throws Exception {
		HttpSession session = request.getSession();
		Integer userid = (Integer) session.getAttribute("foundUserid");

		if (userid != null) {
			CrxVO user = crxService.userInfo(userid);
			ModelAndView mav = new ModelAndView("finishFindId");
			mav.addObject("username", user.getUsername());
			mav.addObject("userid", user.getUserid());
			return mav;
		} else {
			// 세션에 정보가 없을 경우, 회원번호 찾기 페이지로 리다이렉트
			return new ModelAndView("redirect:/findId.do");
		}
	}

	@Override
	@GetMapping("/finishFindPwd.do")
	public ModelAndView finishFindPwd(HttpServletRequest request, HttpServletResponse response) throws Exception {
		HttpSession session = request.getSession();
		String username = (String) session.getAttribute("foundUsername"); // 세션에서 username 가져오기
		String userpwd = (String) session.getAttribute("foundUserpwd"); // 세션에서 userpwd 가져오기

		if (username != null && userpwd != null) {
			ModelAndView mav = new ModelAndView("finishFindPwd");
			mav.addObject("username", username);
			mav.addObject("userpwd", userpwd);
			return mav;
		} else {
			// 세션에 정보가 없을 경우, 비밀번호 찾기 페이지로 리다이렉트
			return new ModelAndView("redirect:/findPwd.do");
		}
	}

	@Override
	@RequestMapping(value = "/selectSignup.do", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView selectSignup(HttpServletRequest request, HttpServletResponse response) throws Exception {
		return new ModelAndView("selectSignup");
	}

	@Override
	@GetMapping("/realSubway.do")
	public ModelAndView realSubway(HttpServletRequest request, HttpServletResponse response) throws Exception {
		return new ModelAndView("realSubway");
	}

	@GetMapping("/mypage.do")
	public ModelAndView mypage(HttpServletRequest request, HttpServletResponse response) throws Exception {
		HttpSession session = request.getSession();
		Integer userIdInt = (Integer) session.getAttribute("userid");
		String usermail = (String) session.getAttribute("usermail");

		CrxVO crxVO;
		if (userIdInt != null) {
			crxVO = crxService.userInfo(userIdInt);
		} else if (usermail != null) {
			crxVO = crxService.userInfoEmail(usermail);
		} else {
			return new ModelAndView("redirect:/login.do"); // 로그인 페이지로 리다이렉트
		}

		session.setAttribute("crxVO", crxVO);

		// 부서별로 데이터를 가져옴
		List<CrxVO> masterList = crxService.memList("통합관리");
		List<CrxVO> reservList = crxService.memList("예매관리");
		List<CrxVO> customerList = crxService.memList("고객안내");
		List<CrxVO> usageList = crxService.memList("이용안내");
		List<CrxVO> tourList = crxService.memList("여행상품");

		// 전체 데이터를 담을 통합 리스트 생성
		List<CrxVO> totalList = new ArrayList<>();

		// 부서별 리스트를 통합 리스트에 추가
		totalList.addAll(masterList);
		totalList.addAll(reservList);
		totalList.addAll(customerList);
		totalList.addAll(usageList);
		totalList.addAll(tourList);

		// totalList를 memid 기준으로 오름차순 정렬
		totalList.sort((o1, o2) -> Integer.compare(o1.getMemid(), o2.getMemid()));

		ModelAndView mav = new ModelAndView("mypage");
		mav.addObject("crxVO", crxVO);
		mav.addObject("masterList", masterList);
		mav.addObject("reservList", reservList);
		mav.addObject("customerList", customerList);
		mav.addObject("usageList", usageList);
		mav.addObject("tourList", tourList);
		mav.addObject("totalList", totalList);
		return mav;
	}

	@PostMapping("/updateUserPwd.do")
	public ModelAndView updateUserPwd(HttpServletRequest request, HttpServletResponse response,
			RedirectAttributes rAttr) throws Exception {
		HttpSession session = request.getSession();
		Integer userIdInt = (Integer) session.getAttribute("userid");
		String usermail = (String) session.getAttribute("usermail");

		if (userIdInt == null && usermail == null) {
			return new ModelAndView("redirect:/login.do"); // 로그인 페이지로 리다이렉트
		}

		String currentPwd = request.getParameter("currentpwd");
		String newPwd = request.getParameter("newpwd");
		String confirmPwd = request.getParameter("confirmpwd");

		// 새 비밀번호와 확인 비밀번호가 일치하는지 확인
		if (newPwd == null || confirmPwd == null || !newPwd.equals(confirmPwd)) {
			rAttr.addFlashAttribute("pwdChangeResult", "새 비밀번호가 일치하지 않습니다.");
			return new ModelAndView("redirect:/mypage.do?tab=userpwd");
		}

		CrxVO currentUser = null;

		if (userIdInt != null) {
			currentUser = crxService.userInfo(userIdInt);

			// 현재 비밀번호가 맞는지 확인
			if ("user".equals(currentUser.getLevel())) {
				if (!currentUser.getUserpwd().equals(currentPwd)) {
					rAttr.addFlashAttribute("pwdChangeResult", "현재 비밀번호가 일치하지 않습니다.");
					return new ModelAndView("redirect:/mypage.do?tab=userpwd");
				}
				currentUser.setUserpwd(newPwd);
				crxService.updatePwdId(currentUser);
			} else {
				if (!currentUser.getMempwd().equals(currentPwd)) {
					rAttr.addFlashAttribute("pwdChangeResult", "현재 비밀번호가 일치하지 않습니다.");
					return new ModelAndView("redirect:/mypage.do?tab=userpwd");
				}
				currentUser.setMempwd(newPwd);
				crxService.updatePwdMem(currentUser);
			}
		} else if (usermail != null) {
			currentUser = crxService.userInfoEmail(usermail);

			// 카카오 로그인 사용자의 경우
			if (currentUser.getUserpwd() == null || currentUser.getUserpwd().trim().isEmpty()) {
				currentUser.setUserpwd(newPwd);
				crxService.updatePwdMail(currentUser);
			} else if (!currentUser.getUserpwd().equals(currentPwd)) {
				rAttr.addFlashAttribute("pwdChangeResult", "현재 비밀번호가 일치하지 않습니다.");
				return new ModelAndView("redirect:/mypage.do?tab=userpwd");
			} else {
				rAttr.addFlashAttribute("pwdChangeResult", "비밀번호가 이미 설정되어 있습니다.");
				return new ModelAndView("redirect:/mypage.do?tab=userpwd");
			}
		}

		rAttr.addFlashAttribute("pwdChangeResult", "비밀번호가 성공적으로 변경되었습니다.");
		return new ModelAndView("redirect:/mypage.do");
	}

	@GetMapping("/zipcode.do")
	public String zipcode() {
		return "zipcode";
	}

	@GetMapping("/chatbot.do")
	public String chatbot() {
		return "chatbot";
	}

	@PostMapping("/gradeUp")
	public ModelAndView updateGrade(@RequestParam("userid") int userid, @RequestParam("level") String level) {
		crxService.updateGrade(userid, level);
		return new ModelAndView("redirect:/mypage.do?tab=leveling");
	}

	@PostMapping("/deleteUser.do")
	public ModelAndView deleteUser(HttpServletRequest request, HttpServletResponse response, RedirectAttributes rAttr)
			throws Exception {
		HttpSession session = request.getSession();
		Integer userIdInt = (Integer) session.getAttribute("userid");
		String status = (String) session.getAttribute("status");

		if (userIdInt == null && !"kakao".equals(status)) {
			return new ModelAndView("redirect:/login.do"); // 로그인 페이지로 리다이렉트
		}

		if ("kakao".equals(status)) {
			// 카카오 사용자 처리
			String inputUsername = request.getParameter("username");
			String inputUsermail = request.getParameter("usermail");

			CrxVO currentUser = crxService.userInfoEmail(inputUsermail);

			if (currentUser != null && currentUser.getUsername().equals(inputUsername)) {
				crxService.deleteUser(currentUser.getUserid()); // 회원 정보 삭제
				session.invalidate(); // 세션 무효화
				rAttr.addFlashAttribute("unregisterResult", "회원 탈퇴가 완료되었습니다.");
				return new ModelAndView("redirect:/main.do"); // 메인 페이지로 리다이렉트
			} else {
				rAttr.addFlashAttribute("unregisterError", "이름 또는 이메일이 일치하지 않습니다.");
				return new ModelAndView("redirect:/mypage.do?tab=unregister"); // 탈퇴 탭으로 다시 리다이렉트
			}
		} else {
			// 일반 사용자 처리
			String inputPassword = request.getParameter("password");
			CrxVO currentUser = crxService.userInfo(userIdInt);

			if (currentUser != null && currentUser.getUserpwd().equals(inputPassword)) {
				crxService.deleteUser(userIdInt); // 회원 정보 삭제
				session.invalidate(); // 세션 무효화
				rAttr.addFlashAttribute("unregisterResult", "회원 탈퇴가 완료되었습니다.");
				return new ModelAndView("redirect:/main.do"); // 메인 페이지로 리다이렉트
			} else {
				rAttr.addFlashAttribute("unregisterError", "비밀번호가 일치하지 않습니다.");
				return new ModelAndView("redirect:/mypage.do?tab=unregister"); // 탈퇴 탭으로 다시 리다이렉트
			}
		}
	}

	@Override
	@PostMapping("/updateMember.do")
	public ModelAndView updateMember(@ModelAttribute("crx") CrxVO crxVO, HttpServletRequest request,
			HttpServletResponse response, RedirectAttributes rAttr) throws Exception {
		crxService.updateMember(crxVO);
		rAttr.addFlashAttribute("registerSuccess", true);
		return new ModelAndView("redirect:/mypage.do?tab=memberjoin");
	}
	
	@GetMapping("/crx/search")
	@ResponseBody
	public List<CrxScheduleVO> searchCrxSchedules(
	        @RequestParam("departureStation") String departureStation,
	        @RequestParam("arrivalStation") String arrivalStation,
	        @RequestParam("departureTime") String departureTimeStr) {

	    Time departureTime = Time.valueOf(departureTimeStr + ":00:00");
	    
	    List<CrxScheduleVO> schedules = crxService.getCrxSchedules(departureStation, arrivalStation, departureTime);
	    
	    return schedules;
	}
}