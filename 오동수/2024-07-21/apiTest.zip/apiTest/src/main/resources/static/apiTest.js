const api_key='vM9i9vHimRjIGJOBSml%2FJErOR3JpNR3PSr6H0QcY2%2BNa16JpiV%2BBgRTYLMrhPXT6ad5%2BwL9fke%2BZoBbAHwfRow%3D%3D'

var xhr = new XMLHttpRequest();
var url = 'http://apis.data.go.kr/1613000/TrainInfoService/getStrtpntAlocFndTrainInfo'; /*URL*/
var queryParams = '?' + encodeURIComponent('serviceKey') + '='+'vM9i9vHimRjIGJOBSml%2FJErOR3JpNR3PSr6H0QcY2%2BNa16JpiV%2BBgRTYLMrhPXT6ad5%2BwL9fke%2BZoBbAHwfRow%3D%3D'; /*Service Key*/
queryParams += '&' + encodeURIComponent('pageNo') + '=' + encodeURIComponent('1'); /**/
queryParams += '&' + encodeURIComponent('numOfRows') + '=' + encodeURIComponent('10'); /**/
queryParams += '&' + encodeURIComponent('_type') + '=' + encodeURIComponent('json'); /**/
queryParams += '&' + encodeURIComponent('depPlaceId') + '=' + encodeURIComponent('NAT010000'); /**/
queryParams += '&' + encodeURIComponent('arrPlaceId') + '=' + encodeURIComponent('NAT011668'); /**/
queryParams += '&' + encodeURIComponent('depPlandTime') + '=' + encodeURIComponent('20230403'); /**/
queryParams += '&' + encodeURIComponent('trainGradeCode') + '=' + encodeURIComponent('00'); /**/
xhr.open('GET', url + queryParams);
xhr.onreadystatechange = function () {
    if (this.readyState == 4) {
        alert('Status: '+this.status+'nHeaders: '+JSON.stringify(this.getAllResponseHeaders())+'nBody: '+this.responseText);
    }
};

xhr.send('');