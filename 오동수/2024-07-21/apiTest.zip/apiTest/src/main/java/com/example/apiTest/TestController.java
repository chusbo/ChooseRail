package com.example.apiTest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class TestController {
	
	/********** 카카오맵 **********/

	// 카카오맵 보기
	@GetMapping("map.do")
	public String map() {
	    return "/apiTest/map"; 
	}

	// 카카오맵(검색 기능 추가)
	@GetMapping("mapSearch.do")
	public String mapSearch() {
	    return "mapSearch"; 
	}

	// 지오로케이션
	@GetMapping("test1.do")
	public String test1() {
		return "/apiTest/test1";
	}   

}
