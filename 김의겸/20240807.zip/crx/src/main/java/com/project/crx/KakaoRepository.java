package com.project.crx;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface KakaoRepository extends JpaRepository<User, String> {
	// 기본적으로 findById 메서드가 제공됨
}