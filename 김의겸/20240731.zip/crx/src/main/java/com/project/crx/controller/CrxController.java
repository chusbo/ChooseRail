package com.project.crx.controller;

import org.springframework.web.servlet.ModelAndView;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public interface CrxController {
	
	ModelAndView main(HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	ModelAndView login(HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	ModelAndView confirm(HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	ModelAndView adultConfirm(HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	ModelAndView findId(HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	ModelAndView findPwd(HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	ModelAndView signup(HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	ModelAndView minorSignup(HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	ModelAndView finishSignup(HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	ModelAndView finishFindId(HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	ModelAndView finishFindPwd(HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	ModelAndView logout(HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	ModelAndView selectSignup(HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	}