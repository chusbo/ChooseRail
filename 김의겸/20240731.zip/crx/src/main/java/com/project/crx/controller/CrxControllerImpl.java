package com.project.crx.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class CrxControllerImpl {

    @GetMapping("/main.do")
    public String main() {
        return "main"; 
    }
    
    @GetMapping("/localtour.do")
    public String localtour() {
        return "localtour"; 
    }
    
    @GetMapping("/list.do")
    public String list() {
        return "list"; 
    }
    
    @GetMapping("/login.do")
    public String login() {
        return "login"; 
    }
    
    @GetMapping("/confirm.do")
    public String confirm() {
        return "confirm"; 
    }
    
    @GetMapping("/adultConfirm.do")
    public String adultConfirm() {
        return "adultConfirm"; 
    }
    
    @GetMapping("/findId.do")
    public String findId() {
        return "findId"; 
    }
    
    @GetMapping("/findPwd.do")
    public String findPwd() {
        return "findPwd"; 
    }
    
    @GetMapping("/signup.do")
    public String signup() {
        return "signup"; 
    }
    
    @GetMapping("/minorSignup.do")
    public String minorSignup() {
        return "minorSignup"; 
    }
    
    @GetMapping("/finishSignup.do")
    public String finishSignup() {
        return "finishSignup"; 
    }
    
    @GetMapping("/chatbot.do")
    public String chatbot() {
        return "chatbot"; 
    }
    
    @GetMapping("/signupTerms.do")
    public String signupTerms() {
        return "signupTerms"; 
    }
    
    @GetMapping("/finishFindId.do")
    public String finishFindId() {
        return "finishFindId"; 
    }
    
    @GetMapping("/finishFindPwd.do")
    public String finishFindPwd() {
        return "finishFindPwd"; 
    }
    
    @GetMapping("/logout.do")
    public String logout() {
        return "logout"; 
    }
    
    @GetMapping("/selectSignup.do")
    public String selectSignup() {
        return "selectSignup"; 
    }
    
}