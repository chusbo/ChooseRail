package com.project.crx.controller;

import org.springframework.web.servlet.ModelAndView;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public interface CrxController {
	
	ModelAndView main(HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	ModelAndView login(HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	ModelAndView confirm(HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	ModelAndView userconfirm(HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	ModelAndView signup(HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	ModelAndView finishSignup(HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	ModelAndView findUserId(HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	ModelAndView findUserPwd(HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	ModelAndView logout(HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	}