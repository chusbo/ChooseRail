package com.project.crx.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

@RestController
public class CrxChatbot {

	@Value("${clova.api.url}")
	private String clovaApiUrl;

	@Value("${clova.api.key}")
	private String clovaApiKey;

	@Value("${train.api.url}")
	private String trainApiUrl;

	@Value("${train.api.key}")
	private String trainApiKey;

	// Clova Chatbot의 요청을 처리하는 엔드포인트
	@PostMapping("/chatbot")
	public ResponseEntity<String> handleChatbot(@RequestBody String request) {
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.set("Content-Type", "application/json");
		headers.set("X-NCP-CHATBOT_SIGNATURE", clovaApiKey);

		HttpEntity<String> entity = new HttpEntity<>(request, headers);
		return restTemplate.exchange(clovaApiUrl, HttpMethod.POST, entity, String.class);
	}

	// 기차 정보를 조회하는 메소드
	@PostMapping("/crxChatbot")
	public ResponseEntity<String> crxChatbot(@RequestBody TrainRequest trainRequest) {
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.set("Content-Type", "application/json");
		headers.set("Authorization", "Bearer " + trainApiKey);

		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(trainApiUrl)
				.queryParam("departure", trainRequest.getDeparture())
				.queryParam("destination", trainRequest.getDestination())
				.queryParam("dateTime", trainRequest.getDateTime());

		HttpEntity<?> entity = new HttpEntity<>(headers);
		ResponseEntity<String> response = restTemplate.exchange(builder.toUriString(), HttpMethod.GET, entity,
				String.class);

		return response;
	}
}

// TrainRequest 클래스 정의
class TrainRequest {
	private String departure;
	private String destination;
	private String dateTime;

	// getters and setters
	public String getDeparture() {
		return departure;
	}

	public void setDeparture(String departure) {
		this.departure = departure;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getDateTime() {
		return dateTime;
	}

	public void setDateTime(String dateTime) {
		this.dateTime = dateTime;
	}
}