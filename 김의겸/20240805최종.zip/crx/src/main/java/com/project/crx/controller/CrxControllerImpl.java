package com.project.crx.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.project.crx.service.CrxService;
import com.project.crx.vo.CrxVO;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@Controller
public class CrxControllerImpl implements CrxController {

	@Autowired
	private CrxService crxService;

	@Autowired
	private CrxVO crxVO;

	@Override
	@GetMapping("/main.do")
	public ModelAndView main(HttpServletRequest request, HttpServletResponse response) throws Exception {
		return new ModelAndView("main");
	}

	@GetMapping("/login.do")
	public String login() {
		return "login"; // login.jsp와 같은 뷰 이름을 반환
	}

	@PostMapping("/login.do")
	public ModelAndView login(@ModelAttribute("crx") CrxVO crxVO, RedirectAttributes rAttr, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		CrxVO loginUser = crxService.login(crxVO);

		if (loginUser != null) {
			// 로그인 성공
			HttpSession session = request.getSession();
			session.setAttribute("loginUser", loginUser);
			session.setAttribute("username", loginUser.getUsername());
			session.setAttribute("userid", loginUser.getUserid()); // userid를 세션에 저장
			session.setAttribute("isLogOn", true);
			// 세션 유효 시간 설정 (예: 30분)
			session.setMaxInactiveInterval(1800); // 초 단위, 30분

			mav.setViewName("redirect:/main.do"); // 일반 사용자 메인 페이지로 리다이렉트

		} else {
			// 로그인 실패
			rAttr.addFlashAttribute("result", "아이디 또는 비밀번호가 일치하지 않습니다.");
			mav.setViewName("redirect:/login.do"); // 로그인 폼 페이지로 리다이렉트
		}
		return mav;
	}

	@Override
	@GetMapping("/logout.do")
	public ModelAndView logout(HttpServletRequest request, HttpServletResponse response) throws Exception {
		HttpSession session = request.getSession();
		session.invalidate(); // 세션 무효화

		// 모든 쿠키 삭제
		Cookie[] cookies = request.getCookies();
		if (cookies != null) {
			for (Cookie cookie : cookies) {
				cookie.setValue(null);
				cookie.setMaxAge(0);
				cookie.setPath("/"); // 쿠키 경로 설정
				response.addCookie(cookie);
			}
		}

		return new ModelAndView("redirect:/main.do"); // 로그인 페이지로 리다이렉트
	}
	
	@PostMapping("/updateUserInfo.do")
    public ModelAndView updateUserInfo(@ModelAttribute("crx") CrxVO crxVO, HttpServletRequest request, HttpServletResponse response) throws Exception {
        HttpSession session = request.getSession();
        Integer userIdInt = (Integer) session.getAttribute("userid");

        if (userIdInt == null) {
            return new ModelAndView("redirect:/login.do"); // 로그인 페이지로 리다이렉트
        }

        crxVO.setUserid(userIdInt);
        crxService.updateUserInfo(crxVO);

        session.setAttribute("crxVO", crxVO); // 업데이트된 정보로 세션 갱신

        return new ModelAndView("redirect:/mypage.do");
    }

	@Override
	@GetMapping("/confirm.do")
	public ModelAndView confirm(HttpServletRequest request, HttpServletResponse response) throws Exception {
		return new ModelAndView("confirm");
	}

	@Override
	@GetMapping("/childConfirm.do")
	public ModelAndView childConfirm(HttpServletRequest request, HttpServletResponse response) throws Exception {
		return new ModelAndView("childConfirm");
	}

	@Override
	@GetMapping("/findId.do")
	public ModelAndView findId(HttpServletRequest request, HttpServletResponse response) throws Exception {
		return new ModelAndView("findId");
	}

	@Override
	@GetMapping("/findPwd.do")
	public ModelAndView findPwd(HttpServletRequest request, HttpServletResponse response) throws Exception {
		return new ModelAndView("findPwd");
	}

	@Override
	@GetMapping("/signup.do")
	public ModelAndView signup(HttpServletRequest request, HttpServletResponse response) throws Exception {
		return new ModelAndView("signup");
	}

	@Override
	@GetMapping("/minorSignup.do")
	public ModelAndView minorSignup(HttpServletRequest request, HttpServletResponse response) throws Exception {
		return new ModelAndView("minorSignup");
	}

	@Override
	@GetMapping("/finishSignup.do")
	public ModelAndView finishSignup(HttpServletRequest request, HttpServletResponse response) throws Exception {
		return new ModelAndView("finishSignup");
	}

	@Override
	@GetMapping("/signupTerms.do")
	public ModelAndView signupTerms(HttpServletRequest request, HttpServletResponse response) throws Exception {
		return new ModelAndView("signupTerms");
	}

	@Override
	@GetMapping("/finishFindId.do")
	public ModelAndView finishFindId(HttpServletRequest request, HttpServletResponse response) throws Exception {
		return new ModelAndView("finishFindId");
	}

	@Override
	@GetMapping("/finishFindPwd.do")
	public ModelAndView finishFindPwd(HttpServletRequest request, HttpServletResponse response) throws Exception {
		return new ModelAndView("finishFindPwd");
	}

	@Override
	@GetMapping("/selectSignup.do")
	public ModelAndView selectSignup(HttpServletRequest request, HttpServletResponse response) throws Exception {
		return new ModelAndView("selectSignup");
	}

	@Override
	@GetMapping("/subway.do")
	public ModelAndView subway(HttpServletRequest request, HttpServletResponse response) throws Exception {
		return new ModelAndView("subway");
	}

	@Override
	@GetMapping("/mypage.do")
	public ModelAndView mypage(HttpServletRequest request, HttpServletResponse response) throws Exception {
		HttpSession session = request.getSession();
		Integer userIdInt = (Integer) session.getAttribute("userid");

		if (userIdInt == null) {
			return new ModelAndView("redirect:/login.do"); // 로그인 페이지로 리다이렉트
		}

		int userid = userIdInt;
		CrxVO crxVO = crxService.getUserInfo(userid);
		session.setAttribute("crxVO", crxVO);

		ModelAndView mav = new ModelAndView("mypage");
		return mav;
	}

	@GetMapping("/zipcode.do")
	public String zipcode() {
		return "zipcode";
	}

	@GetMapping("/chatbot.do")
	public String chatbot() {
		return "chatbot";
	}
}