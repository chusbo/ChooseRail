package com.project.crx;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

@Service
public class KakaoServiceImpl implements KakaoService {

	@Autowired
	private KakaoRepository UserRepository;

	@Override
	public String getToken(String code) throws Exception {
		String accessToken = "";
		final String requestUrl = "https://kauth.kakao.com/oauth/token";

		URL url = new URL(requestUrl);
		HttpURLConnection con = (HttpURLConnection) url.openConnection();
		con.setRequestMethod("POST");
		con.setDoOutput(true);

		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(con.getOutputStream()));
		StringBuilder sb = new StringBuilder();
		sb.append("grant_type=authorization_code");
		sb.append("&client_id=b40dbabe21f0e38eb1ca7cc8451a819c"); // 실제 클라이언트 아이디로 변경
		sb.append("&redirect_uri=http://localhost:8080/kakaoPwd.do");
		sb.append("&code=" + code);
		bw.write(sb.toString());
		bw.flush();

		BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream()));
		StringBuilder resultBuilder = new StringBuilder();
		String line;

		while ((line = br.readLine()) != null) {
			resultBuilder.append(line);
		}

		JsonElement element = JsonParser.parseString(resultBuilder.toString());
		accessToken = element.getAsJsonObject().get("access_token").getAsString();

		br.close();
		bw.close();

		return accessToken;
	}

	public ArrayList<Object> getUserInfo(String accessToken) throws Exception {
		ArrayList<Object> list = new ArrayList<>();

		final String requestUrl = "https://kapi.kakao.com/v2/user/me";
		URL url = new URL(requestUrl);
		HttpURLConnection con = (HttpURLConnection) url.openConnection();
		con.setRequestMethod("GET");
		con.setRequestProperty("Authorization", "Bearer " + accessToken);

		// 응답 처리
		StringBuilder resultBuilder = new StringBuilder();
		try (BufferedReader bf = new BufferedReader(new InputStreamReader(con.getInputStream()))) {
			String line;
			while ((line = bf.readLine()) != null) {
				resultBuilder.append(line);
			}
		}

		// JSON 응답 파싱
		JsonObject jsonObject = JsonParser.parseString(resultBuilder.toString()).getAsJsonObject();
		System.out.println("API Response: " + jsonObject.toString());

		JsonObject kakaoAccount = jsonObject.has("kakao_account") ? jsonObject.getAsJsonObject("kakao_account") : null;

		if (kakaoAccount == null) {
			throw new Exception("Invalid JSON response from Kakao API. KakaoAccount is missing.");
		}

		// 데이터 추출
		String userid = jsonObject.get("id").getAsString();
		String usermail = kakaoAccount.has("email") ? kakaoAccount.get("email").getAsString() : "not provided";
		String username = kakaoAccount.has("name") ? kakaoAccount.get("name").getAsString() : "Unknown";
		String usergender = kakaoAccount.has("gender") ? kakaoAccount.get("gender").getAsString() : "not provided";
		String userbirth = kakaoAccount.has("birthyear") ? kakaoAccount.get("birthyear").getAsString() : "not provided";
		String usertel = kakaoAccount.has("phone_number") ? kakaoAccount.get("phone_number").getAsString()
				: "not provided";

		if (usergender.equals("male")) {
			usergender = "남성";
		} else if (usergender.equals("female")) {
			usergender = "여성";
		}

		list.add(usermail);
		list.add(username);
		list.add(usergender);
		list.add(userbirth);
		list.add(usertel);

		// DB 저장
		User user = new User(usermail, username, usergender, userbirth, usertel);
		UserRepository.save(user);

		return list;
	}
}