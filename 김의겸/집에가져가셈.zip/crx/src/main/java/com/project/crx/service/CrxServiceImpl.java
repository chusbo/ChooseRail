package com.project.crx.service;

import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;

import com.project.crx.dao.CrxDAO;
import com.project.crx.vo.CrxVO;

@Service
public class CrxServiceImpl implements CrxService {

	@Autowired
	private CrxDAO crxDAO;

	@Override
	public CrxVO login(CrxVO crxVO) throws Exception {
		return crxDAO.loginId(crxVO);
	}

	@Override
	public CrxVO userInfo(int userid) {
		return crxDAO.userInfo(userid);
	}

	@Override
	public CrxVO userInfoEmail(String usermail) {
		return crxDAO.userInfoEmail(usermail);
	}

	@Override
	public void updateUserInfo(CrxVO crxVO) throws Exception {
		crxDAO.updateUserInfo(crxVO); // user 테이블 수정
	}

	@Override
	public void updateMemInfo(CrxVO crxVO) throws Exception {
		crxDAO.updateMemInfo(crxVO); // member 테이블 수정
	}

	@Override
	public void updatePwdId(CrxVO crxVO) {
		crxDAO.updatePwdId(crxVO);
	}

	@Override
	public void updatePwdMail(CrxVO crxVO) {
		crxDAO.updatePwdMail(crxVO);
	}
}