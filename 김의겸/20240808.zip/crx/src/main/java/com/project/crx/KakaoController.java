package com.project.crx;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
public class KakaoController {

	@Autowired
	private KakaoService kakaoService;

	@Autowired
	private UserService userService;

	@GetMapping("kakaoTerms")
	public String kakaoConnect() {
		StringBuffer url = new StringBuffer();
		url.append("https://kauth.kakao.com/oauth/authorize?");
		url.append("client_id=b40dbabe21f0e38eb1ca7cc8451a819c"); // 실제 클라이언트 아이디로 변경
		url.append("&redirect_uri=http://localhost:8080/main.do"); // 리디렉션 URI 설정
		url.append("&response_type=code");
		url.append("&prompt=login");

		return "redirect:" + url.toString();
	}

	@RequestMapping(value = "/main.do")
	public String kakaoLogin(@RequestParam("code") String code, Model model, HttpSession session) {
		try {
			System.out.println("kakaoLogin called with code: " + code);
			String accessToken = kakaoService.getToken(code);
			System.out.println("Access Token: " + accessToken);

			ArrayList<Object> list = kakaoService.getUserInfo(accessToken);
			System.out.println("User Info: " + list);

			String userid = (String) list.get(0);
			String usermail = (String) list.get(1);
			String username = (String) list.get(2);
			System.out.println("User ID: " + userid);
			System.out.println("User Email: " + usermail);
			System.out.println("User Name: " + username);

			User user = userService.findByUsermail(usermail);
			if (user == null) {
				user = new User(userid, usermail, username, (String) list.get(3), (String) list.get(4),
						(String) list.get(5));
				userService.saveUser(user);
			}

			session.setAttribute("userid", userid);
			session.setAttribute("usermail", usermail);
			session.setAttribute("username", username);
			session.setAttribute("isLogOn", true);

			// 세션에 저장된 값 로그 출력
			System.out.println("Session User ID: " + session.getAttribute("userid"));
			System.out.println("Session User Email: " + session.getAttribute("usermail"));
			System.out.println("Session User Name: " + session.getAttribute("username"));
			System.out.println("Session isLogOn: " + session.getAttribute("isLogOn"));

			return "redirect:/main.do";
		} catch (Exception e) {
			e.printStackTrace();
			return "error";
		}
	}
}
