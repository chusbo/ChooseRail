package com.project.crx;

public interface UserService {
	User findByUsermail(String usermail);

	void saveUser(User user);
}