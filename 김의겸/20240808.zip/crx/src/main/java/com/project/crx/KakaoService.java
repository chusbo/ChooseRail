package com.project.crx;

import java.util.ArrayList;

import org.springframework.http.ResponseEntity;

public interface KakaoService {
	String getToken(String code) throws Exception;

	ArrayList<Object> getUserInfo(String accessToken) throws Exception;
}
