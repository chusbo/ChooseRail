package com.project.crx.service;

import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;

import com.project.crx.dao.CrxDAO;
import com.project.crx.vo.CrxVO;

@Service
public class CrxServiceImpl implements CrxService {

	@Autowired
	private CrxDAO crxDAO;

	@Override
	public CrxVO login(CrxVO crxVO) throws Exception {
		return crxDAO.loginById(crxVO);
	}

	@Override
	public CrxVO getUserInfo(int userid) {
		return crxDAO.getUserInfo(userid);
	}

	@Override
	public CrxVO getUserInfoEmail(String usermail) {
		return crxDAO.getUserInfoEmail(usermail);
	}

	@Override
	public void updateUserInfo(CrxVO crxVO) throws Exception {
		crxDAO.updateUserInfo(crxVO);
	}

	// 일반 사용자의 비밀번호 변경
	@Override
	public void updatePwdById(CrxVO crxVO) {
		crxDAO.updatePwdById(crxVO);
	}

	// 카카오 로그인 사용자의 비밀번호 초기 설정
	@Override
	public void updatePwdByMail(CrxVO crxVO) {
		crxDAO.updatePwdByMail(crxVO);
	}
}