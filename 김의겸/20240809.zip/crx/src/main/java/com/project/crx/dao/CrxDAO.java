package com.project.crx.dao;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.project.crx.vo.CrxVO;

@Mapper
@Repository("CrxDAO")
public interface CrxDAO {
	CrxVO getUserInfo(int userid);

	CrxVO getUserInfoEmail(String usermail);

	CrxVO loginById(CrxVO crxVO) throws DataAccessException;

	void updateUserInfo(CrxVO crxVO) throws DataAccessException;

	// 일반 사용자의 비밀번호 변경 메서드
	void updatePwdById(CrxVO crxVO);

	// 카카오 로그인 사용자의 비밀번호 초기 설정 메서드
	void updatePwdByMail(CrxVO crxVO);
}