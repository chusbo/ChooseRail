package com.project.crx.service;

import com.project.crx.vo.CrxVO;

public interface CrxService {
	CrxVO login(CrxVO crxVO) throws Exception;

	CrxVO getUserInfo(int userid);

	CrxVO getUserInfoEmail(String usermail);

	void updateUserInfo(CrxVO crxVO) throws Exception;

	// 일반 사용자의 비밀번호 변경
	void updatePwdById(CrxVO crxVO);

	// 카카오 로그인 사용자의 비밀번호 초기 설정
	void updatePwdByMail(CrxVO crxVO);
}