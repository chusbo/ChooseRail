package com.project.crx.vo;

import org.springframework.stereotype.Component;

@Component("CrxVO")
public class CrxVO {
	// user 테이블 필드
	private int userid;
	private String userpwd;
	private String username;
	private String usermail;
	private String usertel;
	private String parenttel;
	private String usergender;
	private String userbirth;
	private String useradd;

	// member 테이블 필드
	private int memid;
	private String mempwd;
	private String memname;
	private String memmail;
	private String memtel;
	private String memdate;
	private String memgender;
	private String membirth;
	private String memgrade;
	private String memadd;
	private int user_userid;
	private String division_divno;

	public int getUserid() {
		return userid;
	}

	public void setUserid(int userid) {
		this.userid = userid;
	}

	public String getUserpwd() {
		return userpwd;
	}

	public void setUserpwd(String userpwd) {
		this.userpwd = userpwd;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getUsermail() {
		return usermail;
	}

	public void setUsermail(String usermail) {
		this.usermail = usermail;
	}

	public String getUsertel() {
		return usertel;
	}

	public void setUsertel(String usertel) {
		this.usertel = usertel;
	}

	public String getParenttel() {
		return parenttel;
	}

	public void setParenttel(String parenttel) {
		this.parenttel = parenttel;
	}

	public String getUsergender() {
		return usergender;
	}

	public void setUsergender(String usergender) {
		this.usergender = usergender;
	}

	public String getUserbirth() {
		return userbirth;
	}

	public void setUserbirth(String userbirth) {
		this.userbirth = userbirth;
	}

	public String getUseradd() {
		return useradd;
	}

	public void setUseradd(String useradd) {
		this.useradd = useradd;
	}

	public int getMemid() {
		return memid;
	}

	public void setMemid(int memid) {
		this.memid = memid;
	}

	public String getMempwd() {
		return mempwd;
	}

	public void setMempwd(String mempwd) {
		this.mempwd = mempwd;
	}

	public String getMemname() {
		return memname;
	}

	public void setMemname(String memname) {
		this.memname = memname;
	}

	public String getMemmail() {
		return memmail;
	}

	public void setMemmail(String memmail) {
		this.memmail = memmail;
	}

	public String getMemtel() {
		return memtel;
	}

	public void setMemtel(String memtel) {
		this.memtel = memtel;
	}

	public String getMemdate() {
		return memdate;
	}

	public void setMemdate(String memdate) {
		this.memdate = memdate;
	}

	public String getMemgender() {
		return memgender;
	}

	public void setMemgender(String memgender) {
		this.memgender = memgender;
	}

	public String getMembirth() {
		return membirth;
	}

	public void setMembirth(String membirth) {
		this.membirth = membirth;
	}

	public String getMemgrade() {
		return memgrade;
	}

	public void setMemgrade(String memgrade) {
		this.memgrade = memgrade;
	}

	public String getMemadd() {
		return memadd;
	}

	public void setMemadd(String memadd) {
		this.memadd = memadd;
	}

	public int getUser_userid() {
		return user_userid;
	}

	public void setUser_userid(int user_userid) {
		this.user_userid = user_userid;
	}

	public String getDivision_divno() {
		return division_divno;
	}

	public void setDivision_divno(String division_divno) {
		this.division_divno = division_divno;
	}

}