package com.project.crx.proxyserver;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class ProxyController {

	private static final Logger logger = LoggerFactory.getLogger(ProxyController.class);

	private final String NAVER_API_URL = "https://naveropenapi.apigw.ntruss.com/map-geocode/v2/geocode";
	private final String NAVER_CLIENT_ID = "8jkyz2i5z7"; // 실제 네이버 클라이언트 아이디
	private final String NAVER_CLIENT_SECRET = "uQF2M7ffg7c0Y5ubY62M2epNKmLi4VggwfSxVIVK"; // 실제 네이버 클라이언트 시크릿

	@GetMapping("/proxy/geocode")
	public ResponseEntity<String> getGeocode(@RequestParam("query") String query) {
		logger.info("Received geocode request for query: " + query);

		String encodedQuery;
		try {
			encodedQuery = URLEncoder.encode(query + " 서울", "UTF-8");
		} catch (UnsupportedEncodingException e) {
			logger.error("Error encoding query: " + query, e);
			return ResponseEntity.badRequest().body("Invalid query parameter");
		}

		RestTemplate restTemplate = new RestTemplate();
		String url = NAVER_API_URL + "?query=" + encodedQuery;
		logger.info("Encoded URL: " + url);

		HttpHeaders headers = new HttpHeaders();
		headers.set("X-NCP-APIGW-API-KEY-ID", NAVER_CLIENT_ID);
		headers.set("X-NCP-APIGW-API-KEY", NAVER_CLIENT_SECRET);

		HttpEntity<String> entity = new HttpEntity<>(headers);
		ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);

		logger.info("Geocode response: " + response.getBody());

		if (response.getStatusCode().is2xxSuccessful()) {
			String responseBody = response.getBody();
			if (responseBody != null && responseBody.contains("\"totalCount\":0")) {
				logger.warn("No results found for query: " + query);
			}
		}

		return response;
	}
}