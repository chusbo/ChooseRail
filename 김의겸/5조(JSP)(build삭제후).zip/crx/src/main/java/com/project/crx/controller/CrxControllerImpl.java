package com.project.crx.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class CrxControllerImpl {

    // 메인페이지
    @GetMapping("/main.do")
    public String main() {
        return "main"; 
    }
    
    // 로그인
    @GetMapping("/login.do")
    public String login() {
        return "login"; 
    }
    
    // 일반 본인인증
    @GetMapping("/confirm.do")
    public String confirm() {
        return "confirm"; 
    }
    
    // 14세 미만 보호자 본인인증
    @GetMapping("/childConfirm.do")
    public String childConfirm() {
        return "childConfirm"; 
    }
    
    // 회원번호 찾기
    @GetMapping("/findId.do")
    public String findId() {
        return "findId"; 
    }
    
    // 비밀번호 찾기
    @GetMapping("/findPwd.do")
    public String findPwd() {
        return "findPwd"; 
    }
    
    // 14세 이상 회원가입
    @GetMapping("/signup.do")
    public String signup() {
        return "signup"; 
    }
    
    // 14세 미만 회원가입
    @GetMapping("/minorSignup.do")
    public String minorSignup() {
        return "minorSignup"; 
    }
    
    // 회원가입 완료
    @GetMapping("/finishSignup.do")
    public String finishSignup() {
        return "finishSignup"; 
    }
    
    // 회원가입 약관
    @GetMapping("/signupTerms.do")
    public String signupTerms() {
        return "signupTerms"; 
    }
    
    // 회원번호 찾기 완료
    @GetMapping("/finishFindId.do")
    public String finishFindId() {
        return "finishFindId"; 
    }
    
    // 비밀번호 찾기 완료
    @GetMapping("/finishFindPwd.do")
    public String finishFindPwd() {
        return "finishFindPwd"; 
    }
    
    // 로그아웃
    @GetMapping("/logout.do")
    public String logout() {
        return "logout"; 
    }
    
    // 14세 이상/미만 선택 페이지
    @GetMapping("/selectSignup.do")
    public String selectSignup() {
        return "selectSignup"; 
    }
    
    // 실시간 지하철
    @GetMapping("/subway.do")
    public String subway() {
        return "subway"; 
    }
    
    @GetMapping("/mypage.do")
    public String mypage() {
        return "mypage"; 
    }
    
    @GetMapping("/zipcode.do")
    public String zipcode() {
        return "zipcode"; 
    }
    
    @GetMapping("/chatbot.do")
    public String chatbot() {
        return "chatbot"; 
    }
    
}