package com.project.crx.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.project.crx.service.TourService;
import com.project.crx.vo.TourVO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;



@Controller
public class TourControllerImpl {

    @GetMapping("/main.do")
    public String main() {
        return "main"; 
    }
    
    @GetMapping("/localtour.do")
    public String localtour() {
        return "localtour"; 
    }
    
    @GetMapping("/tourtrain.do")
    public String tourtrain() {
        return "tourtrain"; 
    }
    
//    @GetMapping("/tourRegister.do")
//    public String tourRegister() {
//        return "tourRegister"; 
//    }
    
    @GetMapping("/dlttrain.do")
    public String dlttrain() {
        return "dlttrain"; 
    }
    
    @GetMapping("/chatbot.do")
    public String chatbot() {
        return "chatbot"; 
    }
    
    @GetMapping("/mypage.do")
    public String mypage() {
        return "mypage"; 
    }
    
    @GetMapping("/zipcode.do")
    public String zipcode() {
        return "zipcode"; 
    }
    
    @GetMapping("/list.do")
    public String list() {
        return "list"; 
    }
    
    @GetMapping("/index.do")
    public String index() {
        return "index"; 
    }

    @GetMapping("/index2.do")
    public String index2() {
        return "index2"; 
    }
    
    @GetMapping("/index3.do")
    public String index3() {
        return "index3"; 
    }
    
    @GetMapping("/index4.do")
    public String index4() {
        return "index4"; 
    }
    
    @GetMapping("/index5.do")
    public String index5() {
        return "index5"; 
    }

    
    // 관광상품 등록
    @GetMapping("/tourRegister.do")
    public ModelAndView tourRegisterForm() {
        ModelAndView mav = new ModelAndView("tourRegister");
        return mav;
    }
    
//    @Override
//    @PostMapping("/tourRegister.do")
//    public ModelAndView tourRegister(HttpServletRequest request, HttpServletResponse response, RedirectAttributes rAttr) throws Exception {
//        ModelAndView mav = new ModelAndView();
//
//        try {
//            TourVO tourVO = new TourVO();
//            tourVO.setTourname(request.getParameter("tourname"));
//            tourVO.setTourno(request.getParameter("tourno"));
//            tourVO.setTitle(request.getParameter("title"));
//            tourVO.setMent(request.getParameter("ment"));
//            tourVO.setContent(request.getParameter("content"));
//            tourVO.setCost(request.getParameter("cost"));
//            tourVO.setNoted(request.getParameter("noted"));
//            tourVO.setFile1(request.getParameter("file1"));
//            tourVO.setFile2(request.getParameter("file2"));
//            tourVO.setFile3(request.getParameter("file3"));
//            
//
//            TourService.insertBoard(tourVO);
//
//            // 성공적으로 등록되었음을 알리는 메시지를 ModelAndView에 직접 추가
//            mav.addObject("message", "공지사항 등록이 완료되었습니다.");
//            mav.setViewName("redirect:/adminBoList.do");
//        } catch(Exception e) {
//            e.printStackTrace();
//            mav.addObject("message", "공지사항 등록 실패했습니다.");
//            mav.setViewName("addBoard");
//        }
//
//        return mav;
//    }
}