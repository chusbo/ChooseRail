package com.project.crx;

import java.sql.SQLException;

public interface PostService {
    
    public void savePost(Post post) throws SQLException;

}
