package com.project.crx.service;

import com.project.crx.vo.CrxVO;

public interface CrxService {
	CrxVO login(CrxVO crxVO) throws Exception;

	CrxVO getUserInfo(int userid);

	void updateUserInfo(CrxVO crxVO) throws Exception;

	void updateUserPwd(CrxVO crxVO) throws Exception;
}
