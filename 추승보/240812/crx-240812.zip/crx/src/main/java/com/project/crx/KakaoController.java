package com.project.crx;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
public class KakaoController {

    @Autowired
    private KakaoService kakaoService;

    @GetMapping("kakaoTerms")
    public String kakaoConnect() {
        StringBuffer url = new StringBuffer();
        url.append("https://kauth.kakao.com/oauth/authorize?");
        url.append("client_id=b40dbabe21f0e38eb1ca7cc8451a819c"); // 실제 클라이언트 아이디로 변경
        url.append("&redirect_uri=http://localhost:8080/kakaologin.do"); // 리디렉션 URI 설정
        url.append("&response_type=code");
        url.append("&prompt=login");

        return "redirect:" + url.toString();
    }

    @RequestMapping(value = "/kakaologin.do")
    public String kakaoLogin(@RequestParam("code") String code, Model model) throws Exception {
        // code로 토큰 받음
        String accessToken = kakaoService.getToken(code);

        // 토큰으로 사용자 정보 담은 list 가져오기
        ArrayList<Object> list = kakaoService.getUserInfo(accessToken);

        // list 모델에 담아 view로 넘김
        model.addAttribute("list", list);

        return "kakaologin";
    }
}
