package com.project.crx;

import java.util.ArrayList;
import java.util.Optional;

public interface KakaoService {
	String getToken(String code) throws Exception;

	ArrayList<Object> getUserInfo(String accessToken) throws Exception;

	Optional<User> getUserByEmail(String usermail);
}