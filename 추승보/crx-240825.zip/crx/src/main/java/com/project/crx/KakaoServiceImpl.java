package com.project.crx;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

@Service
public class KakaoServiceImpl implements KakaoService {

	@Autowired
	private KakaoRepository kakaoRepository;

	@Override
	public String getToken(String code) throws Exception {
		String accessToken = "";
		final String requestUrl = "https://kauth.kakao.com/oauth/token";

		URL url = new URL(requestUrl);
		HttpURLConnection con = (HttpURLConnection) url.openConnection();
		con.setRequestMethod("POST");
		con.setDoOutput(true);

		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(con.getOutputStream()));
		StringBuilder sb = new StringBuilder();
		sb.append("grant_type=authorization_code");
		sb.append("&client_id=b40dbabe21f0e38eb1ca7cc8451a819c"); // 실제 클라이언트 아이디로 변경
		sb.append("&redirect_uri=http://localhost:8080/kakaologin.do");
		sb.append("&code=" + code);
		bw.write(sb.toString());
		bw.flush();

		BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream()));
		StringBuilder resultBuilder = new StringBuilder();
		String line;

		while ((line = br.readLine()) != null) {
			resultBuilder.append(line);
		}

		JsonElement element = JsonParser.parseString(resultBuilder.toString());
		accessToken = element.getAsJsonObject().get("access_token").getAsString();

		br.close();
		bw.close();

		return accessToken;
	}

	@Override
	public ArrayList<Object> getUserInfo(String accessToken) throws Exception {
		ArrayList<Object> list = new ArrayList<>();

		final String requestUrl = "https://kapi.kakao.com/v2/user/me";
		URL url = new URL(requestUrl);
		HttpURLConnection con = (HttpURLConnection) url.openConnection();
		con.setRequestMethod("GET");
		con.setRequestProperty("Authorization", "Bearer " + accessToken);

		StringBuilder resultBuilder = new StringBuilder();
		try (BufferedReader bf = new BufferedReader(new InputStreamReader(con.getInputStream()))) {
			String line;
			while ((line = bf.readLine()) != null) {
				resultBuilder.append(line);
			}
		}

		JsonObject jsonObject = JsonParser.parseString(resultBuilder.toString()).getAsJsonObject();
		JsonObject kakaoAccount = jsonObject.has("kakao_account") ? jsonObject.getAsJsonObject("kakao_account") : null;

		if (kakaoAccount == null) {
			throw new Exception("Invalid JSON response from Kakao API. KakaoAccount is missing.");
		}

		String usermail = kakaoAccount.has("email") ? kakaoAccount.get("email").getAsString() : "not provided";
		String username = kakaoAccount.has("name") ? kakaoAccount.get("name").getAsString() : "Unknown";
		String usergender = kakaoAccount.has("gender") ? kakaoAccount.get("gender").getAsString() : "not provided";
		String userbirth = kakaoAccount.has("birthyear") ? kakaoAccount.get("birthyear").getAsString() : "not provided";
		String usertel = kakaoAccount.has("phone_number") ? kakaoAccount.get("phone_number").getAsString()
				: "not provided";

		if (usertel.startsWith("+82")) {
			usertel = "0" + usertel.substring(3).replace(" ", "");
		}

		// 중복 확인: 이미 존재하는 사용자인지 확인
		Optional<User> existingUserOpt = kakaoRepository.findByUsermail(usermail);
		if (existingUserOpt.isEmpty()) {
			// 새로운 User 객체 생성 (비밀번호 없이)
			User user = new User();
			user.setUsermail(usermail);
			user.setUsername(username);
			user.setUsergender(usergender);
			user.setUserbirth(userbirth);
			user.setUsertel(usertel);

			// level, status, userpwd는 비워둠
			user.setLevel(null); // null로 설정
			user.setStatus(null); // null로 설정
			user.setUserpwd(null); // 비밀번호는 설정되지 않음

			// DB에 사용자 정보 저장 (INSERT)
			User savedUser = kakaoRepository.save(user);

			// 저장된 User의 userid를 리스트에 추가
			list.add(savedUser.getUserid());
		} else {
			// 사용자가 이미 존재할 경우 기존 userid를 리스트에 추가
			list.add(existingUserOpt.get().getUserid());
		}

		list.add(usermail);
		list.add(username);
		list.add(usergender);
		list.add(userbirth);
		list.add(usertel);

		return list;
	}

	@Override
	public Optional<User> getUserByEmail(String usermail) {
		return kakaoRepository.findByUsermail(usermail);
	}
}