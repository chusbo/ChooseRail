package com.project.crx.controller;


import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.project.crx.vo.CusVO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public interface CusController {
	
	/* 고객안내 */
	
	/* 공지사항 */

	// 공지사항 목록
	ModelAndView noticeList(@RequestParam(value = "page", defaultValue = "1") int page,
            				@RequestParam(value = "searchType", required = false) String searchType,
            				@RequestParam(value = "keyword", required = false) String keyword,
            				HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	// 공지사항 등록
	ModelAndView noticeAdd(@RequestParam("notitle") String title,
			  			   @RequestParam("nocontent") String content,
			  			   @RequestParam("nofile") String filename,  
			  			   HttpServletRequest request, 
			  			   HttpServletResponse response, 
			  			   RedirectAttributes rAttr) throws Exception; 
	
	// 공지사항 상세보기
	ModelAndView noticeDetail(int nono, HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	// 공지사항 수정
	ModelAndView noticeUpdate(@ModelAttribute("cusVO") CusVO cusVO,
            				  @RequestParam("nono") int nono,
            				  @RequestParam("nofile") MultipartFile file,
            				  HttpServletRequest request, HttpServletResponse response,
            				  RedirectAttributes rAttr) throws Exception;
	
	// 공지사항 삭제
	ModelAndView noticeDelete(int nono, HttpServletRequest request, HttpServletResponse response, RedirectAttributes rAttr) throws Exception;
	
	
	/* FAQ */

	// FAQ 목록
	ModelAndView faqList(@RequestParam(value = "page", defaultValue = "1") int page,
	        			 @RequestParam(value = "searchType", required = false) String searchType,
	        			 @RequestParam(value = "keyword", required = false) String keyword,
	        			 HttpServletRequest request, HttpServletResponse response) throws Exception;

	// FAQ 등록
	ModelAndView faqAdd(@RequestParam("faqtitle") String title,
						@RequestParam("faqcontent") String content,
	  			  		HttpServletRequest request, 
	  			  		HttpServletResponse response, 
	  			  		RedirectAttributes rAttr) throws Exception; 

	// FAQ 상세보기
	ModelAndView faqDetail(int faqno, HttpServletRequest request, HttpServletResponse response) throws Exception;

	// FAQ 수정
	ModelAndView faqUpdate(@ModelAttribute("cusVO") CusVO cusVO,
	        			   @RequestParam("faqno") int faqno,
	        			   HttpServletRequest request, HttpServletResponse response,
	        			   RedirectAttributes rAttr) throws Exception;

	// FAQ 삭제
	ModelAndView faqDelete(int faqno, HttpServletRequest request, HttpServletResponse response, RedirectAttributes rAttr) throws Exception;
	
	
	/* 유실물 안내 */

	// 유실물 안내 목록
	ModelAndView lostList(@RequestParam(value = "page", defaultValue = "1") int page,
	        			  @RequestParam(value = "searchType", required = false) String searchType,
	        			  @RequestParam(value = "keyword", required = false) String keyword,
	        			  HttpServletRequest request, HttpServletResponse response) throws Exception;

	// 유실물 안내 등록
	ModelAndView lostAdd(@RequestParam("losttitle") String title,
	  			  		 @RequestParam("lostcontent") String content,
	  			  		 @RequestParam("lostplace") String place,
	  			  		 HttpServletRequest request, 
	  			  		 HttpServletResponse response, 
	  			  		 RedirectAttributes rAttr) throws Exception; 

	// 유실물 안내 상세보기
	ModelAndView lostDetail(int lostno, HttpServletRequest request, HttpServletResponse response) throws Exception;

	// 유실물 안내 삭제
	ModelAndView lostDelete(int lostno, HttpServletRequest request, HttpServletResponse response, RedirectAttributes rAttr) throws Exception;

	
	/* Q&A */
	
	// Q&A 목록
	ModelAndView qnaList(@RequestParam(value = "page", defaultValue = "1") int page,
            			 @RequestParam(value = "searchType", required = false) String searchType,
            			 @RequestParam(value = "keyword", required = false) String keyword,
            			 HttpServletRequest request, HttpServletResponse response) throws Exception;
    
    // Q&A 질문 등록
    ModelAndView qnaAdd(@ModelAttribute("cusVO") CusVO cusVO, RedirectAttributes rAttr) throws Exception;
    
    // Q&A 질문 상세보기
    ModelAndView qnaDetail(@RequestParam("qno") int qno) throws Exception;
       
    // Q&A 질문 수정
    ModelAndView qnaUpdate(@ModelAttribute("cusVO") CusVO cusVO, RedirectAttributes rAttr) throws Exception;
    
    // Q&A 질문 삭제
    ModelAndView qnaDelete(@RequestParam("qno") int qno, RedirectAttributes rAttr) throws Exception;
    
    // Q&A 답변 등록
    ModelAndView replyAdd(@ModelAttribute("cusVO") CusVO cusVO, RedirectAttributes rAttr) throws Exception;
        
    // Q&A 답변 수정 추가
    ModelAndView replyUpdate(@ModelAttribute("cusVO") CusVO cusVO, RedirectAttributes rAttr) throws Exception;
       
    // Q&A 답변 삭제
    ModelAndView replyDelete(@RequestParam("rno") int rno, @RequestParam("qno") int qno, RedirectAttributes rAttr) throws Exception;        
}
