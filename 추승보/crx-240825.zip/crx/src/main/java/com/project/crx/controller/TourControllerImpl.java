package com.project.crx.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.project.crx.service.TourService;
import com.project.crx.vo.TourVO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Controller
public class TourControllerImpl implements TourController {

	@Autowired
	private TourService tourService;
	
	//지역상품 페이지
    @GetMapping("/localtour.do")
    public String localtour() {
        return "localtour"; 
    }
    
    @GetMapping("/realBus.do")
    public String realBus() {
        return "realBus"; 
    }
    
    //관광상품 페이지
    @GetMapping("/tourtrain.do")
    public ModelAndView tourList(HttpServletRequest request, HttpServletResponse response) throws Exception {
        List<TourVO> tourList = tourService.tourList();
        ModelAndView mav = new ModelAndView("tourtrain");
        mav.addObject("tourList", tourList);
        return mav;
    }
    
    // 관광상품 등록페이지
    @GetMapping("/tourRegister.do")
    public ModelAndView tourRegisterForm() {
        ModelAndView mav = new ModelAndView("tourRegister");
        return mav;
    }
    
    //관광상품 상세페이지
    @GetMapping("/tourDetail.do")
    public ModelAndView tourDetail(@RequestParam("index") int index, HttpServletRequest request, HttpServletResponse response) throws Exception {
        List<TourVO> tourList = tourService.tourList();
        TourVO tour = tourList.get(index);

        ModelAndView mav = new ModelAndView("tourDetail");
        mav.addObject("tour", tour);
        return mav;
    }
    
    //관광상품 수정페이지
    @GetMapping("/tourMod.do")
    public ModelAndView tourDetail2(@RequestParam("index") int index, HttpServletRequest request, HttpServletResponse response) throws Exception {
        List<TourVO> tourList = tourService.tourList();
        TourVO tour = tourList.get(index);
        ModelAndView mav = new ModelAndView("tourMod");
        mav.addObject("tour", tour);
        return mav;
    }
    
    //관광상품 삭제
    @Override
    @GetMapping("/DeleteTour.do")
    public ModelAndView DeleteTour(@RequestParam("tournum") String tourDelete, HttpServletRequest request, HttpServletResponse response) throws Exception {
        tourService.DeleteTour(tourDelete);
        ModelAndView mav = new ModelAndView("redirect:/tourtrain.do");
        return mav;
    }
    
    @Override
    @PostMapping("/tourReserv")
    public ModelAndView tourReserv(HttpServletRequest request, HttpServletResponse response, RedirectAttributes rAttr) throws Exception {
        ModelAndView mav = new ModelAndView();

        try {
            TourVO TourVO = new TourVO();
            TourVO.setTourtitle(request.getParameter("tourtitle"));
            TourVO.setTourno(request.getParameter("tourno"));
            TourVO.setTourname(request.getParameter("tourname"));
            TourVO.setTourcount(Integer.parseInt(request.getParameter("tourcount")));
            TourVO.setTourdate(request.getParameter("tourdate"));
            TourVO.setTotalcoin(request.getParameter("totalcoin"));
            TourVO.setUserid(Integer.parseInt(request.getParameter("userid")));

            tourService.tourReserv(TourVO);

            // 리다이렉트할 때 파라미터 추가
            rAttr.addAttribute("tournum", request.getParameter("tournum"));
            rAttr.addAttribute("index", request.getParameter("index"));
            rAttr.addAttribute("userid", request.getParameter("userid"));
            rAttr.addFlashAttribute("message", "장바구니에 추가되었습니다.");

            mav.setViewName("redirect:/tourDetail.do");
        } catch(Exception e) {
            e.printStackTrace();
            mav.addObject("message", "장바구니에 추가실패했습니다.");
            mav.setViewName("tourReserv");
        }
        return mav;
    }
    
	//장바구니 페이지
    @GetMapping("/cart.do")
    public ModelAndView cartList(@RequestParam("userid") String userid, HttpServletRequest request, HttpServletResponse response) throws Exception {
        List<TourVO> cartList = tourService.cartList(userid);
        List<TourVO> trainList = tourService.trainList(userid);
        ModelAndView mav = new ModelAndView("cart");
        mav.addObject("cartList", cartList);
        mav.addObject("trainList", trainList);
        mav.addObject("userid", userid);
        return mav;
    }
    
    @PostMapping("/tourDelete")
    public ModelAndView TourDelete(@RequestParam("selectTour") List<Integer> selectedReservations, @RequestParam("userid") String userid) throws Exception {
        
        if (selectedReservations != null) {
            for (Integer reservno : selectedReservations) {
                tourService.delTourCart(reservno);
            }
        }        
        return new ModelAndView("redirect:/cart.do?userid=" + userid);
    }
    
    @PostMapping("/trainDelete")
    public ModelAndView trainDelete(@RequestParam("selectTrainTour") List<Integer> selectedReservations, @RequestParam("userid") String userid) throws Exception {
        
        if (selectedReservations != null) {
            for (Integer reservno : selectedReservations) {
                tourService.delTrainCart(reservno);
            }
        }        
        return new ModelAndView("redirect:/cart.do?userid=" + userid);
    }
    
    @RestController
    @RequestMapping("/api")
    public class BusStationController {

        private final String seoulApiKey = "48554f554e6368753130386943557277";  // 여기에 서울 API 키를 직접 입력

        @GetMapping("/bus-stations")
        public ResponseEntity<?> getBusStations() {
            try {
                String url = "http://openapi.seoul.go.kr:8088/" + seoulApiKey + "/json/StationLoc/1/1000/";
                RestTemplate restTemplate = new RestTemplate();
                ResponseEntity<String> response = restTemplate.getForEntity(url, String.class);
                return ResponseEntity.ok(response.getBody());
            } catch (Exception e) {
                e.printStackTrace();
                return ResponseEntity.status(500).body("Error fetching bus station data");
            }
        }
    }
    
    @GetMapping("/tourPay.do")
    public ModelAndView tourPay(
            @RequestParam("selectTour") List<String> selectedTours, 
            @RequestParam("userid") String userid, 
            @RequestParam("totalAmount") int totalAmount) throws Exception {
        
        // 사용자 ID로 장바구니 목록 조회
        List<TourVO> cartList = tourService.cartList(userid);

        // 선택된 투어 항목만 필터링하여 새로운 리스트로 생성
        List<TourVO> selectedTourList = cartList.stream()
            .filter(tour -> selectedTours.contains(String.valueOf(tour.getReservno())))
            .collect(Collectors.toList());

        // ModelAndView 객체 생성 및 JSP에 데이터 전달
        ModelAndView mav = new ModelAndView("tourPay");
        mav.addObject("selectedTours", selectedTourList); // 선택된 항목 리스트 추가
        mav.addObject("totalAmount", totalAmount); // 클라이언트에서 계산된 총 금액 전달
        return mav;
    }
    
	@PostMapping("/tourpayResult")
	@ResponseBody
	public String handlePaymentResult(
	        @RequestParam("reservno") int reservno,
	        @RequestParam("username") String username,
	        @RequestParam("tourname") String tourname,
	        @RequestParam("tourno") String tourno,
	        @RequestParam("tourdatepay") String tourdateStr, // 문자열로 받기
	        @RequestParam("count") int count,
	        @RequestParam("coin") int coin,
	        @RequestParam("imp_uid") String impUid,
	        @RequestParam("merchant_uid") String merchantUid,
	        @RequestParam("paid_amount") int paidAmount,
	        @RequestParam("apply_num") String applyNum,
	        @RequestParam("userid") int userid
	) {
	    try {
	        // 문자열을 java.util.Date로 변환
	        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	        java.util.Date utilDate = sdf.parse(tourdateStr);

	        // java.util.Date를 java.sql.Date로 변환
	        java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());

	        // CrxVO 객체 생성 및 값 설정
	        TourVO paymentRecord = new TourVO();
	        paymentRecord.setReservno(reservno);
	        paymentRecord.setUsername(username);
	        paymentRecord.setTourname(tourname);
	        paymentRecord.setTourno(tourno);
	        paymentRecord.setTourdatepay(sqlDate); // 변환된 Date 객체 설정
	        paymentRecord.setCount(count);
	        paymentRecord.setCoin(coin);
	        paymentRecord.setImp_uid(impUid);
	        paymentRecord.setMerchant_uid(merchantUid);
	        paymentRecord.setPaid_amount(paidAmount);
	        paymentRecord.setApply_num(applyNum);
	        paymentRecord.setUserid(userid);

	        // 데이터베이스에 저장
	        boolean success = tourService.savePaymentRecord(paymentRecord);
	        return success ? "Success" : "Error";

	    } catch (ParseException e) {
	        e.printStackTrace();
	        return "Error";
	    }
	}
	
	@PostMapping("deltourticket")
	@ResponseBody
	public String deltourticket(@RequestParam("reservno") int reservno) {
	    try {
	        tourService.deltourticket(reservno);
	        return "Success"; 
	    } catch (Exception e) {
	        return "Error";
	    }
	}
	
	@GetMapping("/tourTicketing.do")
	public ModelAndView tourTicketing(@RequestParam("apply_num") String apply_num) throws Exception {
	    List<TourVO> ticket = tourService.tourTicket(apply_num);

	    ModelAndView mav = new ModelAndView("tourTicketing");
	    mav.addObject("ticket", ticket);

	    return mav;
	}
	
    @GetMapping("/mgmtTrain.do")
    public ModelAndView mgmtTrain(@RequestParam("userid") int userid, HttpServletRequest request, HttpServletResponse response) throws Exception {
        List<TourVO> mgmtTrain = tourService.mgmtTrain(userid);        
        ModelAndView mav = new ModelAndView("mgmtTrain");
        mav.addObject("mgmtTrain", mgmtTrain);
        return mav;
    }
    
    @GetMapping("/mgmtTour.do")
    public ModelAndView mgmtTour(@RequestParam("userid") int userid, HttpServletRequest request, HttpServletResponse response) throws Exception {
        List<TourVO> mgmtTour = tourService.mgmtTour(userid);
        ModelAndView mav = new ModelAndView("mgmtTour");
        mav.addObject("mgmtTour", mgmtTour);
        return mav;
    }
    
    @GetMapping("/refundTrain.do")
    public ModelAndView refundTrain(@RequestParam("apply_num") String apply_num, HttpServletRequest request, HttpServletResponse response) throws Exception {
        List<TourVO> refundTrain = tourService.refundTrain(apply_num);
        ModelAndView mav = new ModelAndView("refundTrain");
        mav.addObject("refundTrain", refundTrain);
        return mav;
    }
    
    @GetMapping("/refundTour.do")
    public ModelAndView refundTour(@RequestParam("apply_num") String apply_num, HttpServletRequest request, HttpServletResponse response) throws Exception {
        List<TourVO> refundTour = tourService.refundTour(apply_num);
        ModelAndView mav = new ModelAndView("refundTour");
        mav.addObject("refundTour", refundTour);
        return mav; 
    }
    
    @PostMapping("/refundUpTour")
    public ResponseEntity<String> refundUpTour(@RequestParam("apply_num") String apply_num) {
        try {
            tourService.refundUpTour(apply_num);
            return ResponseEntity.ok("환불 성공");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("환불 실패");
        }
    }
    
    @PostMapping("/refundUpTrain")
    public ResponseEntity<String> refundUpTrain(@RequestParam("apply_num") String apply_num) {
        try {
            tourService.refundUpTrain(apply_num);
            return ResponseEntity.ok("환불 성공");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("환불 실패");
        }
    }

    @GetMapping("/usageTrain.do")
    public ModelAndView usageTrain(@RequestParam("userid") int userid, HttpServletRequest request, HttpServletResponse response) throws Exception {
        List<TourVO> usageTrain = tourService.usageTrain(userid);
        ModelAndView mav = new ModelAndView("usageTrain");
        mav.addObject("usageTrain", usageTrain);
        return mav;
    }
    
    @GetMapping("/usageTour.do")
    public ModelAndView usageTour(@RequestParam("userid") int userid, HttpServletRequest request, HttpServletResponse response) throws Exception {
        List<TourVO> usageTour = tourService.usageTour(userid);
        ModelAndView mav = new ModelAndView("usageTour");
        mav.addObject("usageTour", usageTour);
        return mav;
    }
    
    @GetMapping("/trainSearch")
    public ModelAndView trainSearch(@RequestParam("userid") int userid, 
                                     @RequestParam("startDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date startDate,
                                     @RequestParam("endDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date endDate) throws Exception {
      
        List<TourVO> trainSearch = tourService.trainSearch(userid, startDate, endDate);       
        
        ModelAndView mav = new ModelAndView("usageTrain");
        mav.addObject("trainSearch", trainSearch);
        return mav;
    }
    
    @GetMapping("/tourSearch")
    public ModelAndView tourSearch(@RequestParam("userid") int userid, 
                                     @RequestParam("startDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date startDate,
                                     @RequestParam("endDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date endDate) throws Exception {
      
        List<TourVO> tourSearch = tourService.tourSearch(userid, startDate, endDate);       
        
        ModelAndView mav = new ModelAndView("usageTour");
        mav.addObject("tourSearch", tourSearch);
        return mav;
    }
}