package com.project.crx.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.project.crx.dao.TicketDAO;
import com.project.crx.vo.TicketVO;

@Service
public class TicketServiceImpl implements TicketService {

    private final TicketDAO ticketDAO;

    @Autowired
    public TicketServiceImpl(TicketDAO ticketDAO) {
        this.ticketDAO = ticketDAO;
    }

    @Override
    public void saveReservation(TicketVO reservation) throws Exception {
        ticketDAO.insertReservation(reservation);
    }
    
    @Override
    public List<TicketVO> getPayment() {
        return ticketDAO.getPayment();
    }
    
    @Override
    public List<TicketVO> getTicketing() {
        return ticketDAO.getTicketing();
    }
    
    @Override
    @Transactional
    public boolean savePayment(TicketVO payment) {
        try {
            ticketDAO.insertPayment(payment);
            return true;
        } catch (Exception e) {
            // 로그를 기록합니다.
            System.err.println("Error saving payment: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }


}
