function payMent() {
    alert('결제 페이지로 이동합니다.');
    window.location.href = 'tourpay.do'; // 결제 페이지 URL로 변경
}

function Checkboxes(source, targetClass) {
    var checkboxes = document.getElementsByClassName(targetClass);
    for (var i = 0; i < checkboxes.length; i++) {
        checkboxes[i].disabled = source.checked;
    }
}

function validateForm() {
    // 관광상품 체크박스 중 하나라도 선택되었는지 확인
    var checkboxes = document.getElementsByName("selectTour[]");
    var isChecked = false;
    for (var i = 0; i < checkboxes.length; i++) {
        if (checkboxes[i].checked) {
            isChecked = true;
            break;
        }
    }

    // 선택된 항목이 없으면 alert 띄우기
    if (!isChecked) {
        alert("삭제할 항목을 선택해 주세요.");
        return false; // 폼 제출을 막음
    }

    // 선택된 항목이 있으면 삭제 확인 메시지 띄우기
    return confirm("선택한 항목을 삭제하시겠습니까?");
}

document.addEventListener('DOMContentLoaded', () => {
    const checkboxes = document.querySelectorAll('.tourCheckbox');
    const totalAmountElement = document.getElementById('totalAmount');
    const checkoutButton = document.getElementById('checkoutButton');
    const userIdElement = document.getElementById('userid');

    function updateTotal() {
        let total = 0;
        checkboxes.forEach(checkbox => {
            if (checkbox.checked) {
                const price = parseInt(checkbox.getAttribute('data-price'), 10);
                total += price;
            }
        });
        totalAmountElement.textContent = `${total.toLocaleString('ko-KR')}`;
        return total; // 총금액 반환
    }

	function validateSelection() {
	    const selectedTours = [];
	    let totalAmount = 0;

	    checkboxes.forEach(checkbox => {
	        if (checkbox.checked) {
	            selectedTours.push(checkbox.value); // 선택된 투어 ID를 배열에 추가
	            totalAmount += parseInt(checkbox.getAttribute('data-price'), 10); // 금액을 합산
	        }
	    });

	    if (selectedTours.length > 0) {
	        // 선택된 상품이 있을 경우 결제 페이지로 리디렉션
	        alert('결제 페이지로 이동합니다.');
	        const userId = userIdElement.value; // Hidden input으로부터 사용자 ID 가져오기
	        const selectedToursParam = selectedTours.join(','); // 선택된 투어 ID를 콤마로 연결
	        window.location.href = `tourpay.do?userid=${userId}&selectTour=${selectedToursParam}&totalAmount=${totalAmount}`;
	    } else {
	        // 선택된 상품이 없을 경우 알림 띄우기
	        alert('선택된 상품이 없습니다. 결제할 상품을 선택해 주세요.');
	    }
	}

    checkboxes.forEach(checkbox => {
        checkbox.addEventListener('change', updateTotal);
    });

    checkoutButton.addEventListener('click', validateSelection);
});