package com.project.crx.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class CusControllerImpl {
    
    /********** 공지사항 **********/
    
    // 공지사항 목록
    @GetMapping("/noticeList.do")
    public String noticeList() {
        return "noticeList"; 
    }
    
    // 공지사항 작성
    @GetMapping("/noticeAdd.do")
    public String noticeAdd() {
        return "noticeAdd"; 
    }
    
    // 공지사항 상세보기
    @GetMapping("/noticeDetail.do")
    public String noticeDetail() {
        return "noticeDetail"; 
    }
    
    // 공지사항 수정
    @GetMapping("/noticeMod.do")
    public String noticeMod() {
        return "noticeMod"; 
    }
    
    @GetMapping("/noticeUpdate.do")
    public String noticeUpdate() {
        return "noticeUpdate"; 
    }
    
    // 공지사항 삭제
    @GetMapping("/noticeDelete.do")
    public String noticeDelete() {
        return "noticeList"; 
    }
    
    /********** FAQ **********/
    
    // FAQ 목록
    @GetMapping("/faqList.do")
    public String faqList() {
        return "/faqList"; 
    }
    
    // FAQ 작성
    @GetMapping("/faqAdd.do")
    public String faqAdd() {
        return "/faqAdd"; 
    }
    
    // FAQ 상세보기
    @GetMapping("/faqDetail.do")
    public String faqDetail() {
        return "/faqDetail";
    }
    
    // FAQ 수정
    @GetMapping("/faqMod.do")
    public String faqMod() {
        return "/faqMod"; 
    }
    
    @GetMapping("/faqUpdate.do")
    public String faqUpdate() {
        return "faqUpdate"; 
    }
    
    // FAQ 삭제
    @GetMapping("/faqDelete.do")
    public String faqDelete() {
        return "/faqList"; 
    }
    
    /********** 고객센터 **********/
    
    // 공지사항
    @GetMapping("/customerservice.do")
    public String customerservice() {
        return "customerservice"; 
    }
    
    /********** 유실물 안내 **********/
    
    // 유실물 목록
    @GetMapping("/lostItemList.do")
    public String lostItemList() {
        return "/lostItemList"; 
    }
    
    // 유실물 작성
    @GetMapping("/lostItemAdd.do")
    public String lostItemAdd() {
        return "/lostItemAdd"; 
    }
    
    // 유실물 상세보기
    @GetMapping("/lostItemDetail.do")
    public String lostItemDetail() {
        return "/lostItemDetail";
    }
    
    /********** 안내사항 **********/
    
    // 안내사항
    @GetMapping("/guideline.do")
    public String guideline() {
        return "guideline"; 
    }
    
    /********** Q&A **********/
    
    // Q&A 목록
    @GetMapping("/qnaList.do")
    public String qnaList() {
        return "qnaList"; 
    }
    
    // Q&A 작성
    @GetMapping("/qnaAdd.do")
    public String qnaAdd() {
        return "qnaAdd"; 
    }
    
    // Q&A 상세보기
    @GetMapping("/qnaDetail.do")
    public String qnaDetail() {
        return "qnaDetail"; 
    }
    
    // Q&A 수정
    @GetMapping("/qnaMod.do")
    public String qnaMod() {
        return "qnaMod"; 
    }
    
    @GetMapping("/qnaUpdate.do")
    public String qnaUpdate() {
        return "qnaUpdate"; 
    }
    
    // Q&A 삭제
    @GetMapping("/qnaDelete.do")
    public String qnaDelete() {
        return "qnaList"; 
    }
    
    // Q&A 댓글 목록
    @GetMapping("/replyList.do")
    public String replyList() {
    	return "replyList";
    }
    
    // Q&A 댓글 상세보기
    @GetMapping("/replyDetail.do")
    public String replyDetail() {
    	return "replyDetail";
    }
}