package com.project.crx.vo;

import java.sql.Date;

import org.springframework.stereotype.Component;

@Component("CrxVO")
public class CrxVO {
	// user 테이블 필드
	private int userid;
	private String userpwd;
	private String username;
	private String usermail;
	private String usertel;
	private String parenttel;
	private String usergender;
	private String userbirth;
	private String useradd;
	private String level;
	private String status;
	private String userpost;
	
	// member 테이블 필드
	private int memid;
	private String mempwd;
	private String memname;
	private String memmail;
	private String memtel;
	private String memdate;
	private String memgender;
	private String membirth;
	private String memgrade;
	private String memadd;
	private String mempost;
	private int user_userid;
	private String division_divno;
	
	// division 테이블 필드
	private String divno;
	private String divname;
	
	// notice 테이블 필드
	private int nono;
	private String notitle;
	private String nocontent;
	private String nodate;
	
	private String imp_uid;
	private String merchant_uid;
	private int paid_amount;
	private String apply_num;
	private int reservno;
	private String tourname;
	private String tourno;
	private Date tourdate;
	private int count;
	private int coin;
	
	
	public String getImp_uid() {
		return imp_uid;
	}

	public void setImp_uid(String imp_uid) {
		this.imp_uid = imp_uid;
	}

	public String getMerchant_uid() {
		return merchant_uid;
	}

	public void setMerchant_uid(String merchant_uid) {
		this.merchant_uid = merchant_uid;
	}

	public int getPaid_amount() {
		return paid_amount;
	}

	public void setPaid_amount(int paid_amount) {
		this.paid_amount = paid_amount;
	}

	public String getApply_num() {
		return apply_num;
	}

	public void setApply_num(String apply_num) {
		this.apply_num = apply_num;
	}

	public int getReservno() {
		return reservno;
	}

	public void setReservno(int reservno) {
		this.reservno = reservno;
	}

	public String getTourname() {
		return tourname;
	}

	public void setTourname(String tourname) {
		this.tourname = tourname;
	}

	public String getTourno() {
		return tourno;
	}

	public void setTourno(String tourno) {
		this.tourno = tourno;
	}

	public Date getTourdate() {
		return tourdate;
	}

	public void setTourdate(Date tourdate) {
		this.tourdate = tourdate;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public int getCoin() {
		return coin;
	}

	public void setCoin(int coin) {
		this.coin = coin;
	}

	public int getUserid() {
		return userid;
	}

	public void setUserid(int userid) {
		this.userid = userid;
	}

	public String getUserpwd() {
		return userpwd;
	}

	public void setUserpwd(String userpwd) {
		this.userpwd = userpwd;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getUsermail() {
		return usermail;
	}

	public void setUsermail(String usermail) {
		this.usermail = usermail;
	}

	public String getUsertel() {
		return usertel;
	}

	public void setUsertel(String usertel) {
		this.usertel = usertel;
	}

	public String getParenttel() {
		return parenttel;
	}

	public void setParenttel(String parenttel) {
		this.parenttel = parenttel;
	}

	public String getUsergender() {
		return usergender;
	}

	public void setUsergender(String usergender) {
		this.usergender = usergender;
	}

	public String getUserbirth() {
		return userbirth;
	}

	public void setUserbirth(String userbirth) {
		this.userbirth = userbirth;
	}

	public String getUseradd() {
		return useradd;
	}

	public void setUseradd(String useradd) {
		this.useradd = useradd;
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getUserpost() {
		return userpost;
	}

	public void setUserpost(String userpost) {
		this.userpost = userpost;
	}

	public int getMemid() {
		return memid;
	}

	public void setMemid(int memid) {
		this.memid = memid;
	}

	public String getMempwd() {
		return mempwd;
	}

	public void setMempwd(String mempwd) {
		this.mempwd = mempwd;
	}

	public String getMemname() {
		return memname;
	}

	public void setMemname(String memname) {
		this.memname = memname;
	}

	public String getMemmail() {
		return memmail;
	}

	public void setMemmail(String memmail) {
		this.memmail = memmail;
	}

	public String getMemtel() {
		return memtel;
	}

	public void setMemtel(String memtel) {
		this.memtel = memtel;
	}

	public String getMemdate() {
		return memdate;
	}

	public void setMemdate(String memdate) {
		this.memdate = memdate;
	}

	public String getMemgender() {
		return memgender;
	}

	public void setMemgender(String memgender) {
		this.memgender = memgender;
	}

	public String getMembirth() {
		return membirth;
	}

	public void setMembirth(String membirth) {
		this.membirth = membirth;
	}

	public String getMemgrade() {
		return memgrade;
	}

	public void setMemgrade(String memgrade) {
		this.memgrade = memgrade;
	}

	public String getMemadd() {
		return memadd;
	}

	public void setMemadd(String memadd) {
		this.memadd = memadd;
	}

	public String getMempost() {
		return mempost;
	}

	public void setMempost(String mempost) {
		this.mempost = mempost;
	}

	public int getUser_userid() {
		return user_userid;
	}

	public void setUser_userid(int user_userid) {
		this.user_userid = user_userid;
	}

	public String getDivision_divno() {
		return division_divno;
	}

	public void setDivision_divno(String division_divno) {
		this.division_divno = division_divno;
	}

	public String getDivno() {
		return divno;
	}

	public void setDivno(String divno) {
		this.divno = divno;
	}

	public String getDivname() {
		return divname;
	}

	public void setDivname(String divname) {
		this.divname = divname;
	}

	public int getNono() {
		return nono;
	}

	public void setNono(int nono) {
		this.nono = nono;
	}

	public String getNotitle() {
		return notitle;
	}

	public void setNotitle(String notitle) {
		this.notitle = notitle;
	}

	public String getNocontent() {
		return nocontent;
	}

	public void setNocontent(String nocontent) {
		this.nocontent = nocontent;
	}

	public String getNodate() {
		return nodate;
	}

	public void setNodate(String nodate) {
		this.nodate = nodate;
	}

}