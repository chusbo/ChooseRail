package com.project.crx.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.project.crx.vo.CrxVO;
import com.project.crx.vo.TourVO;

@Mapper
@Repository("CrxDAO")
public interface CrxDAO {
	CrxVO userLogin(CrxVO crxVO) throws DataAccessException;

	CrxVO memberLogin(CrxVO crxVO) throws DataAccessException;

	CrxVO userInfo(int userid);

	CrxVO userInfoEmail(String usermail);

    void updateUserInfo(CrxVO crxVO) throws DataAccessException;

    void updateMemberInfo(CrxVO crxVO) throws DataAccessException;
	
	// 일반 사용자의 비밀번호 변경 메서드
	void updatePwdId(CrxVO crxVO);
	
	void updatePwdMem(CrxVO crxVO);

	// 카카오 로그인 사용자의 비밀번호 초기 설정 메서드
	void updatePwdMail(CrxVO crxVO);
	
	List<CrxVO> memList(String divname) throws DataAccessException;
	
	void updateGrade(@Param("userid") int userid, @Param("level") String level);

	List<CrxVO> mainNotice() throws DataAccessException;

	 void insertPaymentRecord(CrxVO paymentRecord);
}