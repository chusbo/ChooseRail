package com.project.crx;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Transient;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.web.multipart.MultipartFile;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity(name = "tour")
public class Post {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long tournum;

    @Column
    private String tourname;

    @Column
    private String tourno;

    @Column
    private String tourtitle;

    @Column(columnDefinition = "LONGTEXT")
    private String tourcoment;

    @Column(columnDefinition = "LONGTEXT")
    private String tourcontent;

    @Column(columnDefinition = "LONGTEXT")
    private String tourcost;

    @Column(columnDefinition = "LONGTEXT")
    private String tournoted;

    @Transient
    private MultipartFile tourfile1Multipart;

    @Transient
    private MultipartFile tourfile2Multipart;

    @Transient
    private MultipartFile tourfile3Multipart;

    @Column
    private String tourfile1;

    @Column
    private String tourfile2;

    @Column
    private String tourfile3;

    // Getters and Setters
}
