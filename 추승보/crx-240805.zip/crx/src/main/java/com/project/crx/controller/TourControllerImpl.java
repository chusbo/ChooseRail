package com.project.crx.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class TourControllerImpl {
    
    @GetMapping("/localtour.do")
    public String localtour() {
        return "localtour"; 
    }
    
    @GetMapping("/tourtrain.do")
    public String tourtrain() {
        return "tourtrain"; 
    }
    
    // 관광상품 등록
    @GetMapping("/tourRegister.do")
    public ModelAndView tourRegisterForm() {
        ModelAndView mav = new ModelAndView("tourRegister");
        return mav;
    }
    
    @GetMapping("/dlttrain.do")
    public String dlttrain() {
        return "dlttrain"; 
    }
    
    @GetMapping("/index.do")
    public String index() {
        return "index"; 
    }

    @GetMapping("/index2.do")
    public String index2() {
        return "index2"; 
    }
    
    @GetMapping("/index3.do")
    public String index3() {
        return "index3"; 
    }
    
    @GetMapping("/index4.do")
    public String index4() {
        return "index4"; 
    }
    
    @GetMapping("/index5.do")
    public String index5() {
        return "index5"; 
    }
}