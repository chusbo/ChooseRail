package com.project.crx.dao;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.project.crx.vo.CrxVO;

@Mapper
@Repository("CrxDAO")
public interface CrxDAO {
	CrxVO getUserInfo(int userid);

	CrxVO loginById(CrxVO crxVO) throws DataAccessException;

	void updateUserInfo(CrxVO crxVO) throws DataAccessException;

	void updateUserPwd(CrxVO crxVO) throws DataAccessException;
}