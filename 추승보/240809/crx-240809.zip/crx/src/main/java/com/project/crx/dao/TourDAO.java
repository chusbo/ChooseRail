package com.project.crx.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.project.crx.vo.TourVO;

@Mapper
@Repository("TourDAO")
public interface TourDAO {
	List<TourVO> tourList() throws DataAccessException;

	void tourDelete(String tournum);

	void tourReserv(TourVO tourVO);

	List<TourVO> cartList(String userid) throws Exception;
}
