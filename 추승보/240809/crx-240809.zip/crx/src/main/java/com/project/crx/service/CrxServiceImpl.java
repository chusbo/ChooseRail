package com.project.crx.service;

import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;

import com.project.crx.dao.CrxDAO;
import com.project.crx.vo.CrxVO;

@Service
public class CrxServiceImpl implements CrxService {

	@Autowired
	private CrxDAO crxDAO;

	@Override
	public CrxVO login(CrxVO crxVO) throws Exception {
		return crxDAO.loginById(crxVO);
	}

	@Override
	public CrxVO getUserInfo(int userid) {
		return crxDAO.getUserInfo(userid);
	}

	@Override
	public void updateUserInfo(CrxVO crxVO) throws Exception {
		crxDAO.updateUserInfo(crxVO);
	}

	@Override
	public void updateUserPwd(CrxVO crxVO) throws Exception {
		crxDAO.updateUserPwd(crxVO);
	}
}