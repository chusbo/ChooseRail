package com.project.crx.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.project.crx.vo.TicketVO;

@Mapper
public interface TicketDAO {
    void insertReservation(TicketVO reservation) throws Exception;
	List<TicketVO> getReservations();
	List<TicketVO> getPayment();
	void insertPayment(TicketVO payment);
	List<TicketVO> getTicketing();	
}

