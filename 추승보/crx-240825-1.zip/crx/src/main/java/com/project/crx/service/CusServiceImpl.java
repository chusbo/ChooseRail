package com.project.crx.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.crx.dao.CusDAO;
import com.project.crx.vo.CusVO;
import com.project.crx.vo.Search;

@Service
public class CusServiceImpl implements CusService {
	
	// DAO 연결
	@Autowired
	private CusDAO cusDAO;

	/*** 고객안내 ***/	
	
	
	/* 공지사항 */
	
	// 공지사항 목록
	@Override
    public List<CusVO> noticeList(Search search) throws Exception {
        return cusDAO.noticeList(search);
    }
	
	// 공지사항 검색된 게시물 수
    @Override
    public int getNoticeCnt(Search search) throws Exception {
        return cusDAO.getNoticeCnt(search);
    }
	
	// 공지사항 등록
	@Override
	public void noticeAdd(CusVO cusVO) throws Exception {
		cusDAO.noticeAdd(cusVO);
	}
	
	// 공지사항 상세보기
	@Override
	public CusVO noticeDetail(int nono) throws Exception {
	    return cusDAO.noticeDetail(nono);
	}
	
	// 공지사항 조회수 증가
	@Override
	public void noticeHit(int nono) throws Exception {
		cusDAO.noticeHit(nono);
	}
	
	// 공지사항 수정
	@Override
	public void noticeUpdate(CusVO cusVO) throws Exception {
		cusDAO.noticeUpdate(cusVO);
	}
	
	// 공지사항 삭제
	@Override
	public void noticeDelete(int nono) throws Exception {
		cusDAO.noticeDelete(nono);
	}
	
	
	/* FAQ */
	
	// FAQ 목록
	@Override
    public List<CusVO> faqList(Search search) throws Exception {
        return cusDAO.faqList(search);
    }

	// FAQ 검색된 게시물 수
    @Override
    public int getFaqCnt(Search search) throws Exception {
        return cusDAO.getFaqCnt(search);
    }
	
	// FAQ 등록
	@Override
	public void faqAdd(CusVO cusVO) throws Exception {
		cusDAO.faqAdd(cusVO);
	}
	
	// FAQ 상세보기
	@Override
	public CusVO faqDetail(int faqno) throws Exception {
	    return cusDAO.faqDetail(faqno);
	}
	
	// FAQ 조회수 증가
	@Override
	public void faqHit(int faqno) throws Exception {
		cusDAO.faqHit(faqno);
	}
	
	// FAQ 수정
	@Override
	public void faqUpdate(CusVO cusVO) throws Exception {
		cusDAO.faqUpdate(cusVO);
	}
	
	// FAQ 삭제
	@Override
	public void faqDelete(int faqno) throws Exception {
		cusDAO.faqDelete(faqno);
	}
	
	
	/* 유실물 안내 */
	
	// 유실물 안내 목록
	@Override
    public List<CusVO> lostList(Search search) throws Exception {
        return cusDAO.lostList(search);
    }

	// 유실물 안내 검색된 게시물 수
    @Override
    public int getLostCnt(Search search) throws Exception {
        return cusDAO.getLostCnt(search);
    }
	
	// 유실물 안내 등록
	@Override
	public void lostAdd(CusVO cusVO) throws Exception {
		cusDAO.lostAdd(cusVO);
	}
	
	// 유실물 안내 상세보기
	@Override
	public CusVO lostDetail(int lostno) throws Exception {
	    return cusDAO.lostDetail(lostno);
	}
	
	// 유실물 안내 조회수 증가
	@Override
	public void lostHit(int lostno) throws Exception {
		cusDAO.lostHit(lostno);
	}
	
	// 유실물 안내 삭제
	@Override
	public void lostDelete(int lostno) throws Exception {
		cusDAO.lostDelete(lostno);
	}
	
	
	/* Q&A */
	
	// Q&A 질문 목록
    @Override
    public List<CusVO> qnaList(Search search) throws Exception {
        return cusDAO.qnaList(search);
    }
    
    // Q&A 검색된 게시물 수
    @Override
    public int getQnaCnt(Search search) throws Exception {
        return cusDAO.getQnaCnt(search);
    }

    // Q&A 질문 등록
    @Override
    public void qnaAdd(CusVO cusVO) throws Exception {
        cusDAO.qnaAdd(cusVO);
    }

    // Q&A 질문 상세보기
    @Override
    public CusVO qnaDetail(int qno) throws Exception {
        return cusDAO.qnaDetail(qno);
    }
    
    // Q&A 질문 조회수 증가
 	@Override
 	public void qnaHit(int qno) throws Exception {
 		cusDAO.qnaHit(qno);
 	}
 	
    // Q&A 답변 목록
    @Override
    public List<CusVO> replyList(int qno) throws Exception {
        return cusDAO.replyList(qno);
    }

    // Q&A 답변 등록
    @Override
    public void replyAdd(CusVO cusVO) throws Exception {
        cusDAO.replyAdd(cusVO);
    }

    // Q&A 질문 수정
    @Override
    public void qnaUpdate(CusVO cusVO) throws Exception {
        cusDAO.qnaUpdate(cusVO);
    }

    // Q&A 질문 삭제
    @Override
    public void qnaDelete(int qno) throws Exception {
        cusDAO.qnaDelete(qno);
    }
    
    // Q&A 답변 수정
    @Override
    public void replyUpdate(CusVO cusVO) throws Exception {
        cusDAO.replyUpdate(cusVO);
    }

    // Q&A 답변 삭제
    @Override
    public void replyDelete(int rno) throws Exception {
        cusDAO.replyDelete(rno);
    }
}
