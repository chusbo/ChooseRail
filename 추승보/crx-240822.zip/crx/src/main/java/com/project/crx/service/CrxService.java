package com.project.crx.service;

import java.util.List;

import com.project.crx.vo.CrxVO;

public interface CrxService {
    CrxVO login(CrxVO crxVO) throws Exception;

	CrxVO userInfo(int userid);

	CrxVO userInfoEmail(String usermail);

    void updateUserInfo(CrxVO crxVO);

    void updateMemberInfo(CrxVO crxVO);

	// 일반 사용자의 비밀번호 변경
	void updatePwdId(CrxVO crxVO);
	
	void updatePwdMem(CrxVO crxVO);

	// 카카오 로그인 사용자의 비밀번호 초기 설정
	void updatePwdMail(CrxVO crxVO);

	List<CrxVO> memList(String divname) throws Exception;
	
	void updateGrade(int userid, String level);

	List<CrxVO> mainNotice();

	boolean savePaymentRecord(String impUid, String merchantUid, int paidAmount, String applyNum);
}