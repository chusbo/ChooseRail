package com.project.crx.controller;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.project.crx.vo.CrxVO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public interface CrxController {

	// 메인페이지
	ModelAndView main(HttpServletRequest request, HttpServletResponse response) throws Exception;

	// 로그인
	ModelAndView login(CrxVO crxVO, RedirectAttributes rAttr, HttpServletRequest request, HttpServletResponse response) throws Exception;

	// 로그아웃
	ModelAndView logout(HttpServletRequest request, HttpServletResponse response) throws Exception;

	// 일반 본인인증
	ModelAndView confirm(HttpServletRequest request, HttpServletResponse response) throws Exception;

	// 14세 미만 보호자 본인인증
	ModelAndView childConfirm(HttpServletRequest request, HttpServletResponse response) throws Exception;

	// 회원번호 찾기
	ModelAndView findId(HttpServletRequest request, HttpServletResponse response) throws Exception;

	// 비밀번호 찾기
	ModelAndView findPwd(HttpServletRequest request, HttpServletResponse response) throws Exception;

	// 14세 이상 회원가입
	ModelAndView signup(HttpServletRequest request, HttpServletResponse response) throws Exception;

	// 14세 미만 회원가입
	ModelAndView minorSignup(HttpServletRequest request, HttpServletResponse response) throws Exception;

	// 회원가입 완료
	ModelAndView finishSignup(HttpServletRequest request, HttpServletResponse response) throws Exception;

	// 회원번호 찾기 완료
	ModelAndView finishFindId(HttpServletRequest request, HttpServletResponse response) throws Exception;

	// 비밀번호 찾기 완료
	ModelAndView finishFindPwd(HttpServletRequest request, HttpServletResponse response) throws Exception;

	// 14세 이상/미만 선택 페이지
	ModelAndView selectSignup(HttpServletRequest request, HttpServletResponse response) throws Exception;

	// 회원가입 약관
	ModelAndView signupTerms(HttpServletRequest request, HttpServletResponse response) throws Exception;

	// 실시간 지하철
	ModelAndView subway(HttpServletRequest request, HttpServletResponse response) throws Exception;

	// 마이페이지 기본정보
	ModelAndView mypage(HttpServletRequest request, HttpServletResponse response) throws Exception;

    // 유저 정보수정
    ModelAndView updateUserInfo(@ModelAttribute("crx") CrxVO crxVO, RedirectAttributes rAttr,
                                HttpServletRequest request, HttpServletResponse response) throws Exception;

	// 유저 비밀번호 변경
	ModelAndView updateUserPwd(HttpServletRequest request, HttpServletResponse response, RedirectAttributes rAttr)
			throws Exception;
	
}