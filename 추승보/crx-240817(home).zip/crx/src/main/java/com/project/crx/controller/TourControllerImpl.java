package com.project.crx.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.project.crx.service.TourService;
import com.project.crx.vo.TourVO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Controller
public class TourControllerImpl implements TourController {

	@Autowired
	private TourService tourService;
	
	//지역상품 페이지
    @GetMapping("/localtour.do")
    public String localtour() {
        return "localtour"; 
    }
    
    //관광상품 페이지
    @GetMapping("/tourtrain.do")
    public ModelAndView tourList(HttpServletRequest request, HttpServletResponse response) throws Exception {
        List<TourVO> tourList = tourService.tourList();
        ModelAndView mav = new ModelAndView("tourtrain");
        mav.addObject("tourList", tourList);
        return mav;
    }
    
    // 관광상품 등록페이지
    @GetMapping("/tourRegister.do")
    public ModelAndView tourRegisterForm() {
        ModelAndView mav = new ModelAndView("tourRegister");
        return mav;
    }
    
    //관광상품 상세페이지
    @GetMapping("/tourDetail.do")
    public ModelAndView tourDetail(@RequestParam("index") int index, HttpServletRequest request, HttpServletResponse response) throws Exception {
        List<TourVO> tourList = tourService.tourList();
        TourVO tour = tourList.get(index);

        ModelAndView mav = new ModelAndView("tourDetail");
        mav.addObject("tour", tour);
        return mav;
    }
    
    //관광상품 수정페이지
    @GetMapping("/tourMod.do")
    public ModelAndView tourDetail2(@RequestParam("index") int index, HttpServletRequest request, HttpServletResponse response) throws Exception {
        List<TourVO> tourList = tourService.tourList();
        TourVO tour = tourList.get(index);
        ModelAndView mav = new ModelAndView("tourMod");
        mav.addObject("tour", tour);
        return mav;
    }
    
    //관광상품 삭제
    @Override
    @GetMapping("/DeleteTour.do")
    public ModelAndView DeleteTour(@RequestParam("tournum") String tourDelete, HttpServletRequest request, HttpServletResponse response) throws Exception {
        tourService.DeleteTour(tourDelete);
        ModelAndView mav = new ModelAndView("redirect:/tourtrain.do");
        return mav;
    }
    
    @Override
    @PostMapping("/tourReserv")
    public ModelAndView tourReserv(HttpServletRequest request, HttpServletResponse response, RedirectAttributes rAttr) throws Exception {
        ModelAndView mav = new ModelAndView();

        try {
            TourVO TourVO = new TourVO();
            TourVO.setTourtitle(request.getParameter("tourtitle"));
            TourVO.setTourno(request.getParameter("tourno"));
            TourVO.setTourname(request.getParameter("tourname"));
            TourVO.setTourcount(Integer.parseInt(request.getParameter("tourcount")));
            TourVO.setTourdate(request.getParameter("tourdate"));
            TourVO.setTotalcoin(request.getParameter("totalcoin"));
            TourVO.setUserid(request.getParameter("userid"));

            tourService.tourReserv(TourVO);

            // 리다이렉트할 때 파라미터 추가
            rAttr.addAttribute("tournum", request.getParameter("tournum"));
            rAttr.addAttribute("index", request.getParameter("index"));
            rAttr.addAttribute("userid", request.getParameter("userid"));
            rAttr.addFlashAttribute("message", "장바구니에 추가되었습니다.");

            mav.setViewName("redirect:/tourDetail.do");
        } catch(Exception e) {
            e.printStackTrace();
            mav.addObject("message", "장바구니에 추가실패했습니다.");
            mav.setViewName("tourReserv");
        }
        return mav;
    }
    
	//장바구니 페이지
    @GetMapping("/cart.do")
    public ModelAndView cartList(@RequestParam("userid") String userid, HttpServletRequest request, HttpServletResponse response) throws Exception {
        List<TourVO> cartList = tourService.cartList(userid);
        ModelAndView mav = new ModelAndView("cart");
        mav.addObject("cartList", cartList);
        mav.addObject("userid", userid);
        return mav;
    }
    
    @PostMapping("/TourDelete")
    public ModelAndView TourDelete(@RequestParam("selectTour[]") List<String> selectedReservations, @RequestParam("userid") String userid, HttpServletRequest request, HttpServletResponse response) throws Exception {
        
        if (selectedReservations != null) {
            for (String reservno : selectedReservations) {
                tourService.delTourCart(reservno);
            }
        }      
        return new ModelAndView("redirect:/cart.do?userid=" + userid);
    }
    
    @GetMapping("/index.do")
    public String index() {
        return "index"; 
    }
    
    @GetMapping("/index2.do")
    public String index2() {
        return "index2"; 
    }
    
    @RestController
    @RequestMapping("/api")
    public class BusStationController {

        private final String seoulApiKey = "48554f554e6368753130386943557277";  // 여기에 서울 API 키를 직접 입력

        @GetMapping("/bus-stations")
        public ResponseEntity<?> getBusStations() {
            try {
                String url = "http://openapi.seoul.go.kr:8088/" + seoulApiKey + "/json/StationLoc/1/1000/";
                RestTemplate restTemplate = new RestTemplate();
                ResponseEntity<String> response = restTemplate.getForEntity(url, String.class);
                return ResponseEntity.ok(response.getBody());
            } catch (Exception e) {
                e.printStackTrace();
                return ResponseEntity.status(500).body("Error fetching bus station data");
            }
        }
    }
}