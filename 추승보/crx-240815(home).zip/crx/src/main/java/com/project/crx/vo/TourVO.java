package com.project.crx.vo;

public class TourVO {
	private String tournum;
	private String tourname;
	private String tourno;
	private String tourcoin;
	private String tourtitle;
	private String tourcomment;
	private String tourcontent;
	private String tourcost;
	private String tournoted;
	private String file1;
	private String file2;
	private String file3;
	private int reservno;	
	private int tourcount;
	private String tourdate;
	private String totalcoin;
	private String userid;
	
	public String getTournum() {
		return tournum;
	}
	public void setTournum(String tournum) {
		this.tournum = tournum;
	}
	public String getTourname() {
		return tourname;
	}
	public void setTourname(String tourname) {
		this.tourname = tourname;
	}
	public String getTourno() {
		return tourno;
	}
	public void setTourno(String tourno) {
		this.tourno = tourno;
	}
	public String getTourcoin() {
		return tourcoin;
	}
	public void setTourcoin(String tourcoin) {
		this.tourcoin = tourcoin;
	}
	public String getTourtitle() {
		return tourtitle;
	}
	public void setTourtitle(String tourtitle) {
		this.tourtitle = tourtitle;
	}
	public String getTourcomment() {
		return tourcomment;
	}
	public void setTourcomment(String tourcomment) {
		this.tourcomment = tourcomment;
	}
	public String getTourcontent() {
		return tourcontent;
	}
	public void setTourcontent(String tourcontent) {
		this.tourcontent = tourcontent;
	}
	public String getTourcost() {
		return tourcost;
	}
	public void setTourcost(String tourcost) {
		this.tourcost = tourcost;
	}
	public String getTournoted() {
		return tournoted;
	}
	public void setTournoted(String tournoted) {
		this.tournoted = tournoted;
	}
	public String getFile1() {
		return file1;
	}
	public void setFile1(String file1) {
		this.file1 = file1;
	}
	public String getFile2() {
		return file2;
	}
	public void setFile2(String file2) {
		this.file2 = file2;
	}
	public String getFile3() {
		return file3;
	}
	public void setFile3(String file3) {
		this.file3 = file3;
	}
	public int getReservno() {
		return reservno;
	}
	public void setReservno(int reservno) {
		this.reservno = reservno;
	}
	public int getTourcount() {
		return tourcount;
	}
	public void setTourcount(int tourcount) {
		this.tourcount = tourcount;
	}
	public String getTourdate() {
		return tourdate;
	}
	public void setTourdate(String tourdate) {
		this.tourdate = tourdate;
	}
	public String getTotalcoin() {
		return totalcoin;
	}
	public void setTotalcoin(String totalcoin) {
		this.totalcoin = totalcoin;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}	
	
}
