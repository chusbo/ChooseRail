package com.project.crx.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.project.crx.service.CusService;
import com.project.crx.vo.CusVO;

import jakarta.servlet.ServletContext;

@Controller
public class FileController {

    @Autowired
    private CusService cusService;

    @Value("${upload.path}")
    private String uploadPath;

    @Autowired
    private ServletContext servletContext;

    // 파일 업로드
    @PostMapping("/uploadFile")
    public String uploadFile(@RequestParam("nofile") MultipartFile file, CusVO cusVO, RedirectAttributes redirectAttributes) throws Exception {
        try {
            if (file != null && !file.isEmpty()) {
                String realPath = servletContext.getRealPath("/") + uploadPath;

                File dir = new File(realPath);
                if (!dir.exists()) {
                    dir.mkdirs();
                }

                String originalFilename = file.getOriginalFilename();
                String filepath = realPath + File.separator + originalFilename;

                File saveFile = new File(filepath);
                file.transferTo(saveFile);

                cusVO.setFilename(originalFilename);
                cusVO.setFilepath(filepath);
            }

            cusService.noticeAdd(cusVO);
            redirectAttributes.addFlashAttribute("message", "공지사항이 등록되었습니다.");

        } catch (IOException e) {
            e.printStackTrace();
            redirectAttributes.addFlashAttribute("message", "파일 업로드 실패!");
            return "redirect:/noticeAdd.do";
        }

        return "redirect:/noticeList.do";
    }

    // 파일 다운로드
    @GetMapping("/downloadFile")
    public ResponseEntity<Resource> downloadFile(@RequestParam("filename") String filename) {
        if (filename == null || filename.isEmpty()) {
            return ResponseEntity.badRequest().body(null);
        }

        try {
            String realPath = servletContext.getRealPath("/") + uploadPath;
            String decodedFilename = URLDecoder.decode(filename, StandardCharsets.UTF_8.name());
            File file = new File(realPath + File.separator + decodedFilename);

            if (!file.exists()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
            }

            FileInputStream inputStream = new FileInputStream(file);
            InputStreamResource resource = new InputStreamResource(inputStream);

            HttpHeaders headers = new HttpHeaders();
            String encodedFilename = new String(decodedFilename.getBytes(StandardCharsets.UTF_8), StandardCharsets.ISO_8859_1);
            headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + encodedFilename + "\"");

            return ResponseEntity.ok()
                    .headers(headers)
                    .contentLength(file.length())
                    .body(resource);
        } catch (IOException e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }
}
