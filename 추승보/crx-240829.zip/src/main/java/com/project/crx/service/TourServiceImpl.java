package com.project.crx.service;


import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.crx.dao.TourDAO;
import com.project.crx.vo.TourVO;

@Service
public class TourServiceImpl implements TourService{

	@Autowired
	private TourDAO tourDAO;
	
	//관광상품 리스트
    @Override
    public List<TourVO> tourList() throws Exception {
        return tourDAO.tourList();
    }
    
	//관광상품 리스트에서 관광상품 삭제
	@Override
	public void tourDelete(String tournum) throws Exception {
		tourDAO.tourDelete(tournum);
	}
    
	//관광상품 장바구니 추가
	@Override
	public void tourReserv(TourVO tourVO) throws Exception {
		tourDAO.tourReserv(tourVO);
	}
	
	//장바구니 페이지(관광상품)
    @Override
    public List<TourVO> cartList(String userid) throws Exception {
        return tourDAO.cartList(userid);
    }
    
    //장바구니 페이지(기차예매)
    @Override
    public List<TourVO> trainList(String userid) throws Exception {
        return tourDAO.trainList(userid);
    }
    
    //장바구니 관광상품 선택삭제
    public void delTourCart(int reservno) {
        tourDAO.delTourCart(reservno);
    }

	//장바구니 기차예매 선택삭제
    public void delTrainCart(int reservno) {
        tourDAO.delTrainCart(reservno);
    }

	//관광상품 결제 DB저장
    @Override
    public boolean savePaymentRecord(TourVO paymentRecord) {
        try {
            tourDAO.insertPaymentRecord(paymentRecord);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

	//발권관리 페이지(관광상품)
    @Override
    public List<TourVO> tourTicket(int apply_num) throws Exception {
        return tourDAO.tourTicket(apply_num);
    }

	//결제완료시 장바구니 DB삭제(기차예매)
	@Override
	public void deltrainticket(int reservno) throws Exception {
		tourDAO.deltrainticket(reservno);
	}

	//결제완료시 장바구니 DB삭제(관광상품)
	@Override
	public void deltourticket(int reservno) throws Exception {
		tourDAO.deltourticket(reservno);
	}

	//예매관리 페이지(기차예매)
    @Override
    public List<TourVO> mgmtTrain(int userid) throws Exception {
        return tourDAO.mgmtTrain(userid);
    }

	//예매관리 페이지(관광상품)
    @Override
    public List<TourVO> mgmtTour(int userid) throws Exception {
        return tourDAO.mgmtTour(userid);
    }
    
	//환불페이지(기차예매)
    @Override
    public List<TourVO> refundTrain(int apply_num) throws Exception {
        return tourDAO.refundTrain(apply_num);
    }

	//환불페이지(관광상품)
    @Override
    public List<TourVO> refundTour(int apply_num) throws Exception {
        return tourDAO.refundTour(apply_num);
    }

	//환불성공 DB업데이트(기차예매)
	@Override
	public void refundUpTour(int apply_num) throws Exception {
		tourDAO.refundUpTour(apply_num);
	}

	//환불성공 DB업데이트(관광상품)
	@Override
	public void refundUpTrain(int apply_num) throws Exception {
		tourDAO.refundUpTrain(apply_num);
	}

	//이용내역 페이지(기차예매)
    @Override
    public List<TourVO> usageTrain(int userid) throws Exception {
        return tourDAO.usageTrain(userid);
    }
    
	//이용내역 페이지(관광상품)
    @Override
    public List<TourVO> usageTour(int userid) throws Exception {
        return tourDAO.usageTour(userid);
    }

	//이용내역 페이지 기간검색(기차예매)
    @Override
    public List<TourVO> trainSearch(int userid, Date startDate, Date endDate) throws Exception {
        return tourDAO.trainSearch(userid, startDate, endDate);
    }

	//이용내역 페이지 기간검색(관광상품)
    @Override
    public List<TourVO> tourSearch(int userid, Date startDate, Date endDate) throws Exception {
        return tourDAO.tourSearch(userid, startDate, endDate);
    }
}
