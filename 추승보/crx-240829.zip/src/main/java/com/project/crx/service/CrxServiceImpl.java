package com.project.crx.service;

import java.sql.Time;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.crx.dao.CrxDAO;
import com.project.crx.vo.CrxScheduleVO;
import com.project.crx.vo.CrxVO;

@Service
public class CrxServiceImpl implements CrxService {

	@Autowired
	private CrxDAO crxDAO;

	@Override
	public CrxVO login(CrxVO crxVO) throws Exception {
		CrxVO loginUser = null;
		try {
			// user 테이블에서 로그인 시도
			loginUser = crxDAO.userLogin(crxVO);
			if (loginUser != null && "user".equals(loginUser.getLevel())) {
				return loginUser;
			} else {
				// member 테이블에서 로그인 시도
				loginUser = crxDAO.memberLogin(crxVO);
				if (loginUser != null) {
				} else {
					System.out.println("회원번호 또는 비밀번호가 일치하지 않습니다.");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Exception occurred during login: " + e.getMessage());
		}
		return loginUser;
	}

	@Override
	public CrxVO userInfo(int userid) {
		return crxDAO.userInfo(userid);
	}

	@Override
	public CrxVO userInfoEmail(String usermail) {
		return crxDAO.userInfoEmail(usermail);
	}

	@Override
	public void updateUserInfo(CrxVO crxVO) {
		CrxVO currentUser = crxDAO.userInfo(crxVO.getUserid());

		// Kakao 사용자라면 이메일을 변경하지 않음
		if ("kakao".equals(currentUser.getStatus())) {
			crxVO.setUsermail(currentUser.getUsermail());
		}

		crxDAO.updateUserInfo(crxVO);
	}

	@Override
	public void updateMemberInfo(CrxVO crxVO) {
		crxDAO.updateMemberInfo(crxVO);
	}

	// 일반 사용자의 비밀번호 변경
	@Override
	public void updatePwdId(CrxVO crxVO) {
		crxDAO.updatePwdId(crxVO);
	}

	@Override
	public void updatePwdMem(CrxVO crxVO) {
		crxDAO.updatePwdMem(crxVO);
	}

	// 카카오 로그인 사용자의 비밀번호 초기 설정
	@Override
	public void updatePwdMail(CrxVO crxVO) {
		crxDAO.updatePwdMail(crxVO);
	}

	@Override
	public void registerUser(CrxVO crxVO) throws Exception {
		crxDAO.insertUser(crxVO); // user 테이블에 새로운 사용자 정보 삽입
	}

	@Override
	public boolean existChildUser(String username, String parenttel) {
		return crxDAO.existChildUser(username, parenttel);
	}

	@Override
	public boolean existUser(String username, String usertel) {
		return crxDAO.existUser(username, usertel);
	}

	@Override
	public CrxVO findUserId(CrxVO crxVO) throws Exception {
		return crxDAO.findUserId(crxVO);
	}

	@Override
	public CrxVO findUserPwd(CrxVO crxVO) throws Exception {
		return crxDAO.findUserPwd(crxVO);
	}

	@Override
	public List<CrxVO> memList(String divname) throws Exception {
		return crxDAO.memList(divname);
	}

	@Override
	public void updateGrade(int userid, String level) {
		crxDAO.updateGrade(userid, level);
	}

	@Override
	public List<CrxVO> mainNotice() {
		return crxDAO.mainNotice();
	}

	@Override
	public void deleteUser(int userid) throws Exception {
		crxDAO.deleteUser(userid); // DAO를 통해 user 테이블에서 회원 정보 삭제
	}

	@Override
	public void updateMember(CrxVO crxVO) throws Exception {
		crxDAO.updateMember(crxVO);
	}

    @Override
    public List<CrxScheduleVO> getCrxSchedules(String departureStation, String arrivalStation, Time departureTime) {
        return crxDAO.getCrxSchedules(departureStation, arrivalStation, departureTime);
    }
}