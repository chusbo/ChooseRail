package com.project.crx.vo;

import java.sql.Time;

import org.springframework.stereotype.Component;

@Component("CrxScheduleVO")
public class CrxScheduleVO {
    private String trainNumber;
    private String departureStation;
    private String arrivalStation;
    private Time departureTime;
    private Time arrivalTime;
    private Time duration;
    private int fareSpecial;
    private int fareStandard;
    
	public String getTrainNumber() {
		return trainNumber;
	}
	public void setTrainNumber(String trainNumber) {
		this.trainNumber = trainNumber;
	}
	public String getDepartureStation() {
		return departureStation;
	}
	public void setDepartureStation(String departureStation) {
		this.departureStation = departureStation;
	}
	public String getArrivalStation() {
		return arrivalStation;
	}
	public void setArrivalStation(String arrivalStation) {
		this.arrivalStation = arrivalStation;
	}
	public Time getDepartureTime() {
		return departureTime;
	}
	public void setDepartureTime(Time departureTime) {
		this.departureTime = departureTime;
	}
	public Time getArrivalTime() {
		return arrivalTime;
	}
	public void setArrivalTime(Time arrivalTime) {
		this.arrivalTime = arrivalTime;
	}
	public Time getDuration() {
		return duration;
	}
	public void setDuration(Time duration) {
		this.duration = duration;
	}
	public int getFareSpecial() {
		return fareSpecial;
	}
	public void setFareSpecial(int fareSpecial) {
		this.fareSpecial = fareSpecial;
	}
	public int getFareStandard() {
		return fareStandard;
	}
	public void setFareStandard(int fareStandard) {
		this.fareStandard = fareStandard;
	}
	
    
}
