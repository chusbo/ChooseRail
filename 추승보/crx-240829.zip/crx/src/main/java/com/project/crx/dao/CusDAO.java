package com.project.crx.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.project.crx.vo.CusVO;
import com.project.crx.vo.Search;

@Mapper
@Repository("CusDAO")
public interface CusDAO {
	
	/*** 고객안내 ***/
	
	/* 공지사항 */
	
	// 공지사항 목록
	List<CusVO> noticeList(Search search) throws Exception;
	
	// 공지사항 검색
	int getNoticeCnt(Search search) throws Exception;
	
	// 공지사항 등록
	void noticeAdd(CusVO cusVO) throws Exception;
	
	// 공지사항 상세보기
	CusVO noticeDetail(int nono) throws DataAccessException;
	
	// 공지사항 조회수 증가
	void noticeHit(int nono) throws DataAccessException;
	
	// 공지사항 수정
	void noticeUpdate(CusVO cusVO) throws Exception;
	
	// 공지사항 삭제
	void noticeDelete(int nono) throws Exception;
	
	
	/* FAQ */
	
	// FAQ 목록
	List<CusVO> faqList(Search search) throws Exception;
	
	// FAQ 검색
	int getFaqCnt(Search search) throws Exception;
	
	// FAQ 등록
	void faqAdd(CusVO cusVO) throws Exception;
	
	// FAQ 상세보기
	CusVO faqDetail(int faqno) throws DataAccessException;
	
	// FAQ 조회수 증가
	void faqHit(int faqno) throws DataAccessException;
	
	// FAQ 수정
	void faqUpdate(CusVO cusVO) throws Exception;
	
	// FAQ 삭제
	void faqDelete(int faqno) throws Exception;
	
	
	/* 유실물 안내 */
	
	// 유실물 안내 목록
	List<CusVO> lostList(Search search) throws Exception;
	
	// 유실물 안내 검색
	int getLostCnt(Search search) throws Exception;
	
	// 유실물 안내 등록
	void lostAdd(CusVO cusVO) throws Exception;
	
	// 유실물 안내 상세보기
	CusVO lostDetail(int lostno) throws DataAccessException;
	
	// 유실물 안내 조회수 증가
	void lostHit(int lostno) throws DataAccessException;
	
	// 유실물 안내 삭제
	void lostDelete(int lostno) throws Exception;
	
	
	/* Q&A */
	
	// Q&A 질문 목록
    List<CusVO> qnaList(Search search) throws Exception;

    // Q&A 검색
 	int getQnaCnt(Search search) throws Exception;
    
    // Q&A 질문 등록
    void qnaAdd(CusVO cusVO) throws Exception;

    // Q&A 질문 상세보기
    CusVO qnaDetail(int qno) throws Exception;

    // Q&A 질문 조회수 증가
 	void qnaHit(int qno) throws DataAccessException;
    
    // Q&A 답변 목록
    List<CusVO> replyList(int qno) throws Exception;

    // Q&A 답변 등록
    void replyAdd(CusVO cusVO) throws Exception;

    // Q&A 질문 수정
    void qnaUpdate(CusVO cusVO) throws Exception;

    // Q&A 질문 삭제
    void qnaDelete(int qno) throws Exception;
    
    // Q&A 답변 수정
    void replyUpdate(CusVO cusVO) throws Exception;

    // Q&A 답변 삭제
    void replyDelete(int rno) throws Exception;
}
