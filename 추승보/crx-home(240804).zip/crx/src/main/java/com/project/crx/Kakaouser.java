package com.project.crx;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@ToString
@NoArgsConstructor  // Lombok을 사용할 때 기본 생성자를 자동 생성
public class Kakaouser {

    @Id
    private String userid;
    private String email;
    private String name;    
    private String gender;
    private String birthyear;
    private String phone;

    // 기본 생성자 (Lombok 사용 시 필요 없음)
    public Kakaouser() {
    }

    // 모든 필드를 포함하는 생성자
    public Kakaouser(String userid, String email, String name, String gender, String birthyear, String phone) {
    	this.userid = userid;
    	this.email = email;
        this.name = name;        
        this.gender = gender;
        this.birthyear = birthyear;
        this.phone = phone;
    }
}
