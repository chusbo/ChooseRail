package com.project.crx.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class CrxControllerImpl {

    @GetMapping("/main.do")
    public String main() {
        return "main"; 
    }
    
    @GetMapping("/localtour.do")
    public String localtour() {
        return "localtour"; 
    }
    
    @GetMapping("/tourtrain.do")
    public String tourtrain() {
        return "tourtrain"; 
    }
    
    @GetMapping("/tourRegister.do")
    public String tourRegister() {
        return "tourRegister"; 
    }
    
    @GetMapping("/dlttrain.do")
    public String dlttrain() {
        return "dlttrain"; 
    }
    
    @GetMapping("/chatbot.do")
    public String chatbot() {
        return "chatbot"; 
    }
    
    @GetMapping("/mypage.do")
    public String mypage() {
        return "mypage"; 
    }
    
    @GetMapping("/zipcode.do")
    public String zipcode() {
        return "zipcode"; 
    }
}