package com.project.crx;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@ToString
@NoArgsConstructor // Lombok을 사용할 때 기본 생성자를 자동 생성
public class User {

	@Id
	@Column(name = "usermail", unique = true)
	private String usermail;

    @Column(name = "userid", unique = true)
    private int userid;
    
	private String username;
	private String usergender;
	private String userbirth;
	private String usertel;
	private String userpwd;
	private String level;
	private String status;

	public User(String usermail, String username, String usergender, String userbirth, String usertel, String userpwd) {
		this.usermail = usermail;
		this.username = username;
		this.usergender = usergender;
		this.userbirth = userbirth;
		this.usertel = usertel;
		this.userpwd = userpwd;
	}
}