package com.project.crx.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.project.crx.service.TourService;
import com.project.crx.vo.TourVO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Controller
public class TourControllerImpl implements TourController {

	@Autowired
	private TourService tourService;
	
	//지역상품 페이지
    @GetMapping("/localtour.do")
    public String localtour() {
        return "localtour"; 
    }
    
    //관광상품 페이지
    @GetMapping("/tourtrain.do")
    public ModelAndView tourList(HttpServletRequest request, HttpServletResponse response) throws Exception {
        List<TourVO> tourList = tourService.tourList();
        ModelAndView mav = new ModelAndView("tourtrain");
        mav.addObject("tourList", tourList);
        return mav;
    }
    
    // 관광상품 등록페이지
    @GetMapping("/tourRegister.do")
    public ModelAndView tourRegisterForm() {
        ModelAndView mav = new ModelAndView("tourRegister");
        return mav;
    }
    
    //관광상품 상세페이지
    @GetMapping("/tourDetail.do")
    public ModelAndView tourDetail(@RequestParam("index") int index, HttpServletRequest request, HttpServletResponse response) throws Exception {
        List<TourVO> tourList = tourService.tourList();
        TourVO tour = tourList.get(index);

        ModelAndView mav = new ModelAndView("tourDetail");
        mav.addObject("tour", tour);
        return mav;
    }
    
    //관광상품 수정페이지
    @GetMapping("/tourMod.do")
    public ModelAndView tourDetail2(@RequestParam("index") int index, HttpServletRequest request, HttpServletResponse response) throws Exception {
        List<TourVO> tourList = tourService.tourList();
        TourVO tour = tourList.get(index);
        ModelAndView mav = new ModelAndView("tourMod");
        mav.addObject("tour", tour);
        return mav;
    }
    
    //관광상품 삭제
    @Override
    @GetMapping("/DeleteTour.do")
    public ModelAndView DeleteTour(@RequestParam("tournum") String tourDelete, HttpServletRequest request, HttpServletResponse response) throws Exception {
        tourService.DeleteTour(tourDelete);
        ModelAndView mav = new ModelAndView("redirect:/tourtrain.do");
        return mav;
    }
    
    @Override
    @PostMapping("/tourReserv")
    public ModelAndView tourReserv(HttpServletRequest request, HttpServletResponse response, RedirectAttributes rAttr) throws Exception {
        ModelAndView mav = new ModelAndView();

        try {
            TourVO TourVO = new TourVO();
            TourVO.setTourno(request.getParameter("tourno"));
            TourVO.setTourcount(Integer.parseInt(request.getParameter("tourcount")));
            TourVO.setTourdate(request.getParameter("tourdate"));
            TourVO.setTotalcoin(request.getParameter("totalcoin"));

            tourService.tourReserv(TourVO);

            // 리다이렉트할 때 파라미터 추가
            rAttr.addAttribute("tournum", request.getParameter("tournum"));
            rAttr.addAttribute("index", request.getParameter("index"));
            rAttr.addFlashAttribute("message", "장바구니에 추가되었습니다.");

            mav.setViewName("redirect:/tourDetail.do");
        } catch(Exception e) {
            e.printStackTrace();
            mav.addObject("message", "장바구니에 추가실패했습니다.");
            mav.setViewName("tourReserv");
        }
        return mav;
    }
    
	//장바구니 페이지
    @GetMapping("/cart.do")
    public String cart() {
        return "cart"; 
    }
}