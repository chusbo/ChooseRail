package com.project.crx;

import java.sql.SQLException;

import org.springframework.web.multipart.MultipartFile;

public interface PostService {
    void savePost(Post post) throws SQLException;
    String saveFile(MultipartFile file) throws Exception;
    void updatePost(Post post) throws SQLException;
}
