package com.project.crx.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class CrxControllerImpl {

    @GetMapping("/main.do")
    public String main() {
        return "main"; 
    }
    
    @GetMapping("/localtour.do")
    public String localtour() {
        return "localtour"; 
    }
    
    @GetMapping("/tourtrain.do")
    public String tourtrain() {
        return "tourtrain"; 
    }
    
    @GetMapping("/dlttrain.do")
    public String dlttrain() {
        return "dlttrain"; 
    }
    
    @GetMapping("/chatbot.do")
    public String chatbot() {
        return "chatbot"; 
    }
}