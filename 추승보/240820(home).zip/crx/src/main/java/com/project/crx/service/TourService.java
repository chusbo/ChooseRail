package com.project.crx.service;

import java.util.List;

import com.project.crx.vo.TourVO;

public interface TourService {
	List<TourVO> tourList() throws Exception;

	void DeleteTour(String tourDelete) throws Exception;

	void tourReserv(TourVO tourVO) throws Exception;

	List<TourVO> cartList(String userid) throws Exception;

	void delTourCart(String reservno);
}
