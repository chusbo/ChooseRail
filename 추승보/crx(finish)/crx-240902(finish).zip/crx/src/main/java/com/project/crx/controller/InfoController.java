package com.project.crx.controller;

import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestParam;

public interface InfoController {
	   
	ResponseEntity<Map<String, Integer>> checkTicket(@RequestParam("applyNum") String applyNum) throws Exception;
}
	