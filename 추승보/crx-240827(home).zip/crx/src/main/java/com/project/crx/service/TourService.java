package com.project.crx.service;

import java.util.Date;
import java.util.List;

import com.project.crx.vo.TourVO;

public interface TourService {
	List<TourVO> tourList() throws Exception;

	void DeleteTour(String tourDelete) throws Exception;
	
	void DeleteTrain(String trainDelete) throws Exception;

	void tourReserv(TourVO tourVO) throws Exception;

	List<TourVO> cartList(String userid) throws Exception;
	
	List<TourVO> trainList(String userid) throws Exception;

	void delTourCart(int reservno);
	
	void delTrainCart(int reservno);
	
	boolean savePaymentRecord(TourVO paymentRecord);

	List<TourVO> tourTicket(String apply_num) throws Exception;

	void deltourticket(int reservno) throws Exception;
	
	void deltrainticket(int reservno) throws Exception;

	List<TourVO> mgmtTrain(int userid) throws Exception;
	
	List<TourVO> mgmtTour(int userid) throws Exception;

	List<TourVO> refundTrain(String apply_num) throws Exception;
	
	List<TourVO> refundTour(String apply_num) throws Exception;

	void refundUpTour(String apply_num) throws Exception;

	void refundUpTrain(String apply_num) throws Exception;

	List<TourVO> usageTrain(int userid) throws Exception;
	
	List<TourVO> usageTour(int userid) throws Exception;
	
	List<TourVO> trainSearch(int userid, Date startDate, Date endDate) throws Exception;

	List<TourVO> tourSearch(int userid, Date startDate, Date endDate) throws Exception;

	
}
