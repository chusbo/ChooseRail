package com.project.crx.service;


import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.crx.dao.TourDAO;
import com.project.crx.vo.TourVO;

@Service
public class TourServiceImpl implements TourService{

	@Autowired
	private TourDAO tourDAO;
	
    @Override
    public List<TourVO> tourList() throws Exception {
        return tourDAO.tourList();
    }
    
	@Override
	public void DeleteTour(String tournum) throws Exception {
		tourDAO.tourDelete(tournum);
	}
	
	@Override
	public void DeleteTrain(String tournum) throws Exception {
		tourDAO.tourDelete(tournum);
	}
    
	@Override
	public void tourReserv(TourVO tourVO) throws Exception {
		tourDAO.tourReserv(tourVO);
	}
	
    @Override
    public List<TourVO> cartList(String userid) throws Exception {
        return tourDAO.cartList(userid);
    }
    
    @Override
    public List<TourVO> trainList(String userid) throws Exception {
        return tourDAO.trainList(userid);
    }
    
    public void delTourCart(int reservno) {
        tourDAO.delTourCart(reservno);
    }
    
    public void delTrainCart(int reservno) {
        tourDAO.delTrainCart(reservno);
    }
    
    @Override
    public boolean savePaymentRecord(TourVO paymentRecord) {
        try {
            tourDAO.insertPaymentRecord(paymentRecord);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    @Override
    public List<TourVO> tourTicket(String apply_num) throws Exception {
        return tourDAO.tourTicket(apply_num);
    }
    
	@Override
	public void deltrainticket(int reservno) throws Exception {
		tourDAO.deltrainticket(reservno);
	}
	
	@Override
	public void deltourticket(int reservno) throws Exception {
		tourDAO.deltourticket(reservno);
	}
	
    @Override
    public List<TourVO> mgmtTrain(int userid) throws Exception {
        return tourDAO.mgmtTrain(userid);
    }
    
    @Override
    public List<TourVO> mgmtTour(int userid) throws Exception {
        return tourDAO.mgmtTour(userid);
    }
    
    @Override
    public List<TourVO> refundTrain(String apply_num) throws Exception {
        return tourDAO.refundTrain(apply_num);
    }
    
    @Override
    public List<TourVO> refundTour(String apply_num) throws Exception {
        return tourDAO.refundTour(apply_num);
    }
    
	@Override
	public void refundUpTour(String apply_num) throws Exception {
		tourDAO.refundUpTour(apply_num);
	}
	
	@Override
	public void refundUpTrain(String apply_num) throws Exception {
		tourDAO.refundUpTrain(apply_num);
	}
	
    @Override
    public List<TourVO> usageTrain(int userid) throws Exception {
        return tourDAO.usageTrain(userid);
    }
	
    @Override
    public List<TourVO> usageTour(int userid) throws Exception {
        return tourDAO.usageTour(userid);
    }
    
    @Override
    public List<TourVO> trainSearch(int userid, Date startDate, Date endDate) throws Exception {
        return tourDAO.trainSearch(userid, startDate, endDate);
    }
    
    @Override
    public List<TourVO> tourSearch(int userid, Date startDate, Date endDate) throws Exception {
        return tourDAO.tourSearch(userid, startDate, endDate);
    }
}
