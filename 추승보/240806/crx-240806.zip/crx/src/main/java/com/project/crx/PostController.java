package com.project.crx;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import jakarta.servlet.http.HttpServletRequest;

@Controller
@RequestMapping("/smarteditor")
public class PostController {

    @Autowired
    private PostService postService;

    @PostMapping("/savePost")
    public ModelAndView savePost(HttpServletRequest req, Post post, ModelMap model) throws Exception {
        // 파일 업로드 처리
        if (!post.getFile1Multipart().isEmpty()) {
            String filePath = saveFile(post.getFile1Multipart());
            post.setFile1(filePath);
        }

        if (!post.getFile2Multipart().isEmpty()) {
            String filePath = saveFile(post.getFile2Multipart());
            post.setFile2(filePath);
        }

        if (!post.getFile3Multipart().isEmpty()) {
            String filePath = saveFile(post.getFile3Multipart());
            post.setFile3(filePath);
        }

        // 포스트 저장 로직
        postService.savePost(post);

        model.addAttribute("result", HttpStatus.OK);
        return new ModelAndView("redirect:/tourtrain.do");
    }

    private String saveFile(MultipartFile file) throws Exception {
        String uploadDir = "src/main/webapp/img/"; // 업로드할 디렉토리
        Path uploadPath = Paths.get(uploadDir);

        // 디렉토리가 존재하지 않으면 생성
        if (!Files.exists(uploadPath)) {
            Files.createDirectories(uploadPath);
        }

        Path filePath = uploadPath.resolve(file.getOriginalFilename());
        Files.copy(file.getInputStream(), filePath);
        return filePath.toString();
    }
}
