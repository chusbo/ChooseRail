package com.project.crx.service;

import java.util.List;

import com.project.crx.vo.TourVO;

public interface TourService {
	   List<TourVO> tourList() throws Exception;
}
