package com.project.crx.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.project.crx.service.TourService;
import com.project.crx.vo.TourVO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Controller
public class TourControllerImpl implements TourController {

	@Autowired
	private TourService tourService;
	
	//지역상품 페이지
    @GetMapping("/localtour.do")
    public String localtour() {
        return "localtour"; 
    }
    
    //관광상품 페이지
    @GetMapping("/tourtrain.do")
    public ModelAndView tourList(HttpServletRequest request, HttpServletResponse response) throws Exception {
        List<TourVO> tourList = tourService.tourList();
        ModelAndView mav = new ModelAndView("tourtrain");
        mav.addObject("tourList", tourList);
        return mav;
    }
    
    // 관광상품 등록
    @GetMapping("/tourRegister.do")
    public ModelAndView tourRegisterForm() {
        ModelAndView mav = new ModelAndView("tourRegister");
        return mav;
    }
    
    //관광상품 상세페이지
    @GetMapping("/tourDetail.do")
    public ModelAndView tourDetail(@RequestParam("index") int index, HttpServletRequest request, HttpServletResponse response) throws Exception {
        List<TourVO> tourList = tourService.tourList();
        TourVO tour = tourList.get(index);

        ModelAndView mav = new ModelAndView("tourDetail");
        mav.addObject("tour", tour);
        return mav;
    }
    
    //관광상품 수정페이지
    @GetMapping("/tourMod.do")
    public ModelAndView tourDetail2(@RequestParam("index") int index, HttpServletRequest request, HttpServletResponse response) throws Exception {
        List<TourVO> tourList = tourService.tourList();
        TourVO tour = tourList.get(index);

        ModelAndView mav = new ModelAndView("tourMod");
        mav.addObject("tour", tour);
        return mav;
    }
}